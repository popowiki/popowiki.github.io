/* Copyright (C) 2014-2019 PopoWiki Project */
// v.1
// note
//   DOM texterea.value is obj.val() : jquery
function popo_get_jq_obj()  //jquery
{
  return $( "#msg" );
}
function popo_get_obj()
{
  var obj;
//  obj = $( "#msg" ); if (obj) { obj = obj.get(0); } //jquery
  return ((obj = document.getElementsByName("msg")) ? obj.item(0) : null);
}
function popo_get_selection()
{
   var obj = popo_get_obj();
   if ( obj )
    {
      var p_start  = obj.selectionStart;
      var p_end    = obj.selectionEnd;
      var v = obj.value;
      if (! ((p_start == null) || (p_start == undefined) || (p_start == NaN)) )
       {
          if ( v.length > 0)
          {
            return v.substr(p_start , p_end - p_start);
          }
       }
    }
    return '';
}
function popo_set_selection(text)
{
  var obj = popo_get_obj();
   if ( obj )
    {
      var p_start  = obj.selectionStart;
      var p_end    = obj.selectionEnd;
      var has_position = true;
      var s;
      var v = obj.value;
      if ((p_start == null) || (p_start == undefined) || (p_start == NaN))
       {
          p_start = p_end = Math.max(0,v.length);
       }

      s = v.substr(0,p_start) + text + v.substr(p_end, v.length-p_end);
      obj.value = s;
      if (( s.length > 0) && (has_position) )
      {
         obj.selectionStart = p_start;
         obj.selectionEnd = p_start + text.length;
      }
      return true;
    }
    return false;
}

function popo_selection_replace(regexp, newString)
{
   var obj = popo_get_obj();
    if ( obj )
    {
      var v = popo_get_selection();
      popo_set_selection(v.replace(regexp , newString));
      obj.focus();
    }
}
function popo_selection_end()
{
   var obj = popo_get_obj();
    if ( obj )
    {
       var x = obj.selectionEnd;
       if (! ((x == null) || (x == undefined) || (x == NaN)) )
        {
           obj.selectionStart = obj.selectionEnd;
        }
       obj.focus();
    }
}
function popo_selection_line_replace(regexp, newString, mode , multiline)
{
  // todo : line
  // obj.selectionStart : minimun IE9 , vista
   var obj = popo_get_obj();
   if ( obj )
    {
      var p_start  = obj.selectionStart;
      var p_end    = obj.selectionEnd;
      var v , v1, v2 , v3 , i , ch , line_start , line_end;
      var has_position = true;
      v = obj.value;
      // move to last when you can not get selection
      if ((p_start == null) || (p_start == undefined) || (p_start == NaN))
        {
          has_position = false;
          p_start = p_end = Math.max(0,v.length);
        }
      line_start = p_start;
      line_end = (multiline ? p_end : line_start);
//      alert("[" + p_start + ":" + p_end + "]" + "[" + line_start + ":" + line_end + "]");
      for(i=p_start-1; i>=0; i--)
      {
         ch = v.substr(i,1);
         if ( (ch == "\r") || (ch == "\n") )
          { break; }
         line_start = i;
      }
      for(i=(multiline ? p_end : p_start); i<=v.length-1; i++)
      {
         ch = v.substr(i,1);
         if ( (ch == "\r") || (ch == "\n") )
          { break; }
         line_end = i+1;
      }

        v1 = v.substr(0,line_start);
        v2 = v.substr(line_start, line_end - line_start);
        v3 = v.substr(line_end, v.length-line_end);

      v2 = v2.replace(regexp , newString);
      obj.value = v1 + v2 + v3;

     if (has_position)
     {
       if (mode == 'next')
        {
          obj.selectionEnd   = obj.value.length - v3.length + 1;
          obj.selectionStart = obj.selectionEnd;
        }
        else
        {
          obj.selectionStart = line_start;
          obj.selectionEnd   = line_start + v2.length;
        }
     }
      obj.focus();
    }
}
function popo_selection_is_matched(regexp)
{
   var v = popo_get_selection();
   return regexp.test(v);
}
/* JavaScript Objects : https://msdn.microsoft.com/en-us/library/ie/htbw4ywd%28v=vs.94%29.aspx */
/* regex : https://developer.mozilla.org/ja/docs/Web/JavaScript/Guide/Regular_Expressions */
// non selection is no replace (.*) --> (.+)
function popo_selection_replace_twin_togle(mark)
{
   var t = popo_regex_escape(mark);
   var t2 = (mark + '').replace(/\$/ , '\$');
   var rx = new RegExp('^' + mark + '(.*)' + mark + '$');
   if (popo_selection_is_matched(rx))
    { popo_selection_replace(rx , "$1" ); }
   else
    { popo_selection_replace(/^(.*)/ , t2 + "$1" + t2); }
}
function popo_regex_escape(str)
{
   return (str + '').replace(new RegExp('[.\\\\+*?\\[\\^\\]$(){}=!<>|:\\-\/]', 'g'), '\\$&');
}
function popo_func_str_repeat(text , n)
{
  /* IE: error "".repeat(n) not supported. minmun supported Windows10 */
   var ret = "";
   for(var i = 1; i<=n; i++) { ret = ret + text; }
   return ret;
}

function popo_bold()   { popo_selection_replace_twin_togle("''"); }
function popo_italic() { popo_selection_replace_twin_togle("'''"); }
function popo_notes()  {
   var rx = new RegExp(popo_regex_escape('((') + '(.*)' + popo_regex_escape('))'));
   if (popo_selection_is_matched(rx))
    { popo_selection_replace(rx , "$1" ); }
   else
    { popo_selection_replace(/^(.*)/ , "\(\(" + "$1" + "\)\)"); }
}
function popo_block(name)  { popo_selection_line_replace(/^([.\s\S]*)$/ , "$1" + "\n#"+name , 'next'); }
function popo_add(text)    { popo_selection_replace(/^([.\s\S]*)/m , "$1"+text); popo_selection_end(); }
function popo_inline(name) { popo_selection_replace(/^([.\s\S]*)/m , "&"+name+";"); popo_selection_end(); }
function popo_inline_double(quote) { popo_selection_replace_twin_togle(quote+""); }
function popo_inlineEx(name, value)
{
  // &name(){}
  var to;
  to = "&"+name+";"
  if (arguments.length >= 2)
    { to = "&"+name+"("+ value +"){$1};" }
  else if (arguments.length == 1)
    { to = "&"+name+"($1);" }
  popo_selection_replace(/^([.\s\S]*)/m , to); popo_selection_end();
}
function popo_li(n)       { popo_selection_line_replace(/^[\-]*[ ]*(.*)/ , popo_func_str_repeat("-",n) + " $1"); }
function popo_li_num(n)  { popo_selection_line_replace(/^[\+]*[ ]*(.*)/ , popo_func_str_repeat("+",n) + " $1"); }
function popo_h(n)        { popo_selection_line_replace(/^[\*]*[ ]*(.*)/ , popo_func_str_repeat("*",n) + " $1"); }
function popo_hr4()       { popo_selection_line_replace(/^([.\s\S]*)$/ , "$1" + "\n" + popo_func_str_repeat("-",4) , 'next'); }
function popo_contents()  { popo_block("contents"); }
function popo_comments() {
   // todo each line
   popo_selection_line_replace(/^([.\s\S]*?)$/ , "//" + "$1" , 'next', true);
}

// todo: get line set line
// get current_line
// shift right left