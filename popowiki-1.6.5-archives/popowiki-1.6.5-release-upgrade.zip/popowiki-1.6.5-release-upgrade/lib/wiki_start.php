<?php

/*
 * PopoWiki   PHP Web Wiki System
 *   Copyright (C) 2014-2019 PopoWiki Project
 *   PopoWiki 1.4.8 is forked from PukiWiki 1.4.8(CVS devel ,2011)
 *
 * PukiWiki - Yet another WikiWikiWeb clone
 *   Copyright (C)  2002-2011 PukiWiki Developers Team
 *   Copyright (C)  2001-2002 Originally written by yu-ji
 *
 *   License: GPL v2 or (at your option) any later version
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * (see licenses/ for more info)
 */

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
/**/

if ( version_compare(PHP_VERSION, '5.3.0', '<') )
    exit("This script requires PHP version 5.3 or later.");

if (! function_exists('try_define') ) {
    function try_define($name, $value) { if (!defined($name)) define($name, $value); }
}

try_define('DATA_HOME', '');

/////////////////////////////////////////////////
// Include subroutines

try_define('LIB_DIR', '');

if ( !defined('SETTINGS_DIR') )
{
    if (file_exists(DATA_HOME.'pukiwiki.ini.php'))
        define('SETTINGS_DIR', DATA_HOME); // pukiwiki mode
    else
        define('SETTINGS_DIR', 'settings/');
}

global $mobile_detect;
$mobile_detect = null;
if ( defined('POPOWIKI_ENABLE_MOBILE_DETECT') && POPOWIKI_ENABLE_MOBILE_DETECT
     && is_file(LIB_DIR . 'thirdparty/mobiledetect/Mobile_Detect.php') )
{
    include_once(LIB_DIR . 'thirdparty/mobiledetect/Mobile_Detect.php');
    $mobile_detect = new Mobile_Detect;
}

require_once(LIB_DIR . 'class/user.php');
require_once(LIB_DIR . 'class/link.php');

require(LIB_DIR . 'func.php');
require(LIB_DIR . 'file.php');
require(LIB_DIR . 'plugin.php');
require(LIB_DIR . 'html.php');
require(LIB_DIR . 'backup.php');

require(LIB_DIR . 'convert_html.php');
require(LIB_DIR . 'make_link.php');
require(LIB_DIR . 'diff.php');
require(LIB_DIR . 'config.php');
require(LIB_DIR . 'link.php');
require(LIB_DIR . 'auth.php');
require(LIB_DIR . 'proxy.php');

if ( ! extension_loaded('mbstring') )
  {
     /* require(LIB_DIR . 'mbstring.php'); */
     $msg = "error: extension mbstring is not loadeded <br>\n";
     if ( preg_match('/WINNT/i' , PHP_OS) )
     {
        $msg .= "SEE php.ini : extension=php_mbstring.dll <br>\n";
     }
     die_message($msg);
  }
 
// Defaults
$notify = 0;

// Load *.ini.php files and init PukiWiki
require(LIB_DIR . 'init.php');

\popowiki\core\User::AutoLogin(); // login check


// Load optional libraries
if ( $notify )
{
    require(LIB_DIR . 'mail.php'); // Mail notification
}

/////////////////////////////////////////////////
// Main

$retvars = array();
$page = isset($vars['page']) ? $vars['page'] : '';
$refer = isset($vars['refer']) ? $vars['refer'] : '';

if ( isset($vars['cmd']) )
{
    $plugin = & $vars['cmd'];
}
else if ( isset($vars['plugin']) )
{
    $plugin = & $vars['plugin'];
}
else
{
    $plugin = '';
}

// Plugin execution
if ( $plugin != '' )
{
    if ( exist_plugin_action($plugin) )
    {
        $retvars = do_plugin_action($plugin);
        if ( $retvars === FALSE )
            exit; // Done


// Rescan $vars (Some plugins rewrite it)
        if ( isset($vars['cmd']) )
        {
            $base = isset($vars['page']) ? $vars['page'] : '';
        }
        else
        {
            $base = isset($vars['refer']) ? $vars['refer'] : '';
        }
    }
    else
    {
        $msg = 'plugin=' . HtmlUtils::escapeHTML($plugin) . ' is not implemented.';
        $retvars = array('msg' => $msg, 'body' => $msg);
        $base = & $defaultpage;
    }
}

// Page output
$title = HtmlUtils::escapeHTML(strip_bracket($base));
$page = make_search($base);
if ( isset($retvars['msg']) && $retvars['msg'] != '' )
{
    $title = str_replace('$1', $title, $retvars['msg']);
    $page = str_replace('$1', $page, $retvars['msg']);
}

if ( isset($retvars['body']) && $retvars['body'] != '' )
{
    $body = & $retvars['body'];
}
else
{
    if ( $base == '' || !is_page($base) )
    {
        $base = & $defaultpage;
        $title = HtmlUtils::escapeHTML(strip_bracket($base));
        $page = make_search($base);
    }

    $vars['cmd'] = 'read';
    $vars['page'] = & $base;

    $body = convert_html(get_source($base), array('page'=>$base));
}

// Output
catbody($title, $page, $body);
exit;
 