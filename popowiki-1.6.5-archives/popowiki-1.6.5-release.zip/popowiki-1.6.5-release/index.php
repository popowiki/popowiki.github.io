<?php
/*
 * PopoWiki's start up file.
 *
 * PopoWiki   PHP Web Wiki System
 *   Copyright (C) 2014-2019 PopoWiki Project
 *   PopoWiki 1.4.8 is forked from PukiWiki 1.4.8(CVS devel ,2011)
 * PukiWiki - Yet another WikiWikiWeb clone
 *   Copyright (C)  2002-2011 PukiWiki Developers Team
 *   Copyright (C)  2001-2002 Originally written by yu-ji
 *
 *   License: GPL v2 or (at your option) any later version
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * (see licenses/ for more info)
 */

if ( version_compare(PHP_VERSION, '5.3.0', '<') )
    exit("This script requires PHP version 5.3 or later.");

// Error reporting
//error_reporting(0); // Nothing
error_reporting(E_ERROR | E_PARSE); // Avoid E_WARNING, E_NOTICE, etc
//error_reporting((E_ALL | E_STRICT) & ~E_NOTICE); // Debug purpose
//error_reporting(E_ALL); // Debug purpose
// ini_set('display_errors', "0" );

// Special
//define('PKWK_READONLY',  1);
//define('PKWK_SAFE_MODE', 1);
//define('PKWK_OPTIMISE',  1);
//define('TDIARY_THEME',   'digital_gadgets');
//define('PUKIWIKI_THEME',   '1');

// Directory definition
// (Ended with a slash like '../path/to/pkwk/', or '')
define('DATA_HOME',	'');
define('LIB_DIR',	'lib/');

// skin
//define('POPOWIKI_SKIN_URI', 'skin/');
//define('POPOWIKI_ENABLE_MOBILE_DETECT', 1);

// PopoWiki
define('SETTINGS_DIR',	'settings/');   // new ver 1.4.8 : settings/
define('HIDE_VERSION_STRING', 1);       // 1 hide : popowiki , php version.
//define('OUTPUT_HIDE_CORE_POWERDBY', 1); // 1 hide : popowiki Powered by.
//define('OUTPUT_HIDE_CONVERT_TIME', 1);  // 1 hide : HTML convert time

//define('SKIN_DEFAULT_SHOW_LINK_PATH', 1);  // debug
//define('OUTPUT_SIMPLE_MENU', 1);  // debug

//define('SKIN_DEFAULT_BODY_HEADER_CUSTUM_EREA' , '<b>block right</b>');

// override $page_title
//define('PAGE_TITLE' , 'Your Site Title' );

// right munu for popowiki skin

//$GLOBALS['MenuBar_Right']
$MenuBar_Right = array();
$MenuBar_Right['menu_pagename'] = 'MenuBar-Right';
  // right menu : you can write html tag.
$MenuBar_Right['source_html_tag'] = array(
        'head' => '', // <b>Header</b>
        'foot' => ''  // <b>Footer</b>
    );

//define('POPO_STYLE_H_INDEX' , 'pink' );
//define('POPO_STYLE_H_INDEX' , 'brown' );
//define('POPO_STYLE_H_INDEX' , 'blue' );
//define('POPO_STYLE_H_INDEX' , 'green' );
/* 'pink' , 'brown' , 'blue', 'green', 'green2', 'green3' */

// start wiki
require(LIB_DIR . 'wiki_start.php');

// 