<?php
/*
 * PopoWiki   PHP Web Wiki System
 * Copyright (C) 2014-2019 PopoWiki Project
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * (see licenses/ for more info)
 */

function get_js_popo_editor_toolbar()
{
   global $_pp_editor_title;
   if (!isset($_pp_editor_title)) $_pp_editor_title = array();
   $title = &$_pp_editor_title;

   $tp_btn = "<a href='javascript:void(0);' onclick='popo_%s(); return false;'>%s</a>";
   $tp_btn2 = "<a href='javascript:void(0);' onclick='popo_%s; return false;'>%s</a>";
   $btn_list = array();
   $tools = array();

   // * ** ***
   for ($i = 1;$i<=3;$i++)
     $btn_list[] = sprintf($tp_btn2 , "h({$i})" , "h{$i}");

   $btn_list[] = sprintf($tp_btn , 'bold'   , isset($title['bold']) ? $title['bold'] : 'bold');
   $btn_list[] = sprintf($tp_btn , 'italic' , isset($title['italic']) ? $title['italic'] : 'italic');
   $btn_list[] = sprintf($tp_btn2 , 'inline_double("%%")' , isset($title['strike']) ? $title['strike'] : 'strike');
   $btn_list[] = sprintf($tp_btn , 'notes' , isset($title['notes']) ? $title['notes'] : 'notes');
   $btn_list[] = sprintf($tp_btn , 'contents' , isset($title['contents']) ? $title['contents'] : 'contents');

   $tools[] = implode(' | ', $btn_list);
   $btn_list = array();

   $btn_list[] = "list";
   // - -- ---
   for ($i = 1;$i<=3;$i++)
     $btn_list[] = sprintf($tp_btn2 , "li({$i})" , str_repeat("-",$i) );
   // + ++ +++
   for ($i = 1;$i<=3;$i++)
     $btn_list[] = sprintf($tp_btn2 , "li_num({$i})" , str_repeat("+",$i) );
     
   $tools[] = implode(' | ', $btn_list);
   $btn_list = array();

   $btn_list[] = sprintf($tp_btn2 , 'add("[[]]")' , isset($title['[[]]']) ? $title['[[]]'] : '[[]]');

   $btn_list[] = sprintf($tp_btn2 , 'inline("br")' , isset($title['br']) ? $title['br'] : '&br;');
   $btn_list[] = sprintf($tp_btn2 , 'block("br")' , isset($title['br']) ? $title['br'] : '#br');

   $btn_list[] = sprintf($tp_btn2 , 'block("hr")' , isset($title['hr']) ? $title['hr'] : '#hr');
   $btn_list[] = sprintf($tp_btn , 'hr4' , isset($title['hr4']) ? $title['hr4'] : 'hr(----)');
   $btn_list[] = sprintf($tp_btn , 'comments' , isset($title['comments']) ? $title['comments'] : 'comments');

   $btn_list[] = sprintf($tp_btn2 , 'block("clear")' , isset($title['clear']) ? $title['clear'] : '#clear');
   $btn_list[] = sprintf($tp_btn2 , 'block("ref()")' , isset($title['clear']) ? $title['clear'] : '#ref()');
   $btn_list[] = sprintf($tp_btn2 , 'inlineEx("ref")' , isset($title['ref']) ? $title['ref'] : '&ref();');

   $tools[] = implode(' | ', $btn_list);
   $btn_list = array();

   $btn_list[] = sprintf($tp_btn2 , 'inlineEx("size", "size")' , isset($title['size']) ? $title['size'] : '&size(size){text};');
   $btn_list[] = sprintf($tp_btn2 , 'inlineEx("color","color,bg color")' , isset($title['color']) ? $title['color'] : '&color(color,bg color){text};');
   $btn_list[] = sprintf($tp_btn2 , 'inline("aname(name){text}")' , isset($title['aname']) ? $title['aname'] : '&aname(name){text};');
   $btn_list[] = sprintf($tp_btn2 , 'inlineEx("ruby", "ruby")' , isset($title['ruby']) ? $title['ruby'] : '&ruby(ruby){text};');
   
   $tools[] = implode(' | ', $btn_list) . "<br />\n";
   return implode("<br />\n", $tools);
}