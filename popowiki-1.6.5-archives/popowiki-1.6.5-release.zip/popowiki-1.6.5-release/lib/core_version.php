<?php
/* this file is auto generated */
/* main/php_version.h like */

define('CORE_MAJOR_VERSION',     1 );
define('CORE_MINOR_VERSION',     6 );
define('CORE_RELEASE_VERSION',   5 );
define('CORE_EXTRA_VERSION', "" ); // -dev , -beta , -rc
define('CORE_VERSION',   "1.6.5" );
define('CORE_VERSION_ID', 10605 );

// dev , beta , rc ,  x.x-dev , x.x-beta1
// dev < alpha = a < beta = b < RC = rc < # < pl = p
// version_compare(): '1.5.0RC1' --> '1.5.0.RC.1' ,  _ + - --> .
