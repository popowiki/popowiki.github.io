<?php

// logout.inc.php
// Copyright (c) 2016 popowiki
/**/


function plugin_logout_action()
{
    global $user, $_LANG;

//    if ( PKWK_READONLY )
//        die_message('PKWK_READONLY prohibits editing');
    $s_logout = (isset($_LANG['skin']['m_logout'])? $_LANG['skin']['m_logout'] : 'Logout');

    $retvars = array('msg' =>HtmlUtils::escapeHTML($s_logout), 'body'=>'&nbsp;');
    $goConvert = true;

    $has_session = isset($_SESSION);
    $_SESSION = array();
    if (ini_get("session.use_cookies")) {
        setcookie(session_name(), '', time() - 42000);
    }

    if (is_object($user) && $user->isLoggedIn())
    {
        $user->logout();
        $retvars['body'] .= (isset($_LANG['skin']['m_loggedout'])? $_LANG['skin']['m_loggedout'] : 'logged out');
    }
    if ($has_session)
        @session_destroy();
    return $retvars;
}
