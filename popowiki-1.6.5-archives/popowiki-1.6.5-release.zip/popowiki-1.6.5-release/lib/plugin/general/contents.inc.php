<?php
// PukiWiki - Yet another WikiWikiWeb clone
// $Id: contents.inc.php,v 1.1 2005/04/10 18:41:02 teanan Exp $
//
/**/

function plugin_contents_convert()
{
	// This character string is substituted later.
	return '<#_contents_>';
}

function plugin_contents_allow_no_login()
{
    return TRUE;
}
