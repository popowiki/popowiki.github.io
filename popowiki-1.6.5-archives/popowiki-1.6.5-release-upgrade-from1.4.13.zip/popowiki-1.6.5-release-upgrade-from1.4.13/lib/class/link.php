<?php
/*
 * PopoWiki   PHP Web Wiki System
 * Copyright (C) 2014-2019 PopoWiki Project
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * (see licenses/ for more info)
 */
namespace popowiki\core;
//use ;

class Link
{
    static function getPageUrl($pagename, $params = array())
    {
        global $script;
        if (isset($params[$pagename]))
            unset($params[$pagename]);
        $q = self::urlencode($pagename);
        $q2 = http_build_query($params);
        if ((strlen($q) > 0) && (strlen($q2) > 0))
            $q .= '&';
        if (strlen($q) == 0)
            return $script;
        return $script . '?' . $q;
    }

    static function getCmdUrl($cmdname, $params = array())
    {
        global $script;
        if (isset($params['cmd']))
            unset($params['cmd']);
        $params = array_merge(array('cmd'=>$cmdname), $params);
        $q = http_build_query($params);
        return $script . '?' . $q;
    }

    static function getPageLink($pagename, $Text, $option = array('attributes'=>array(),'params'=>array()))
    {
        global $script;
        $params = array();
        if (isset($option['params']) && is_array($option['params']))
            $params =& $option['params'];
        $attr = '';
        if (isset($option['attributes']))
        {
            if (is_array($option['attributes']))
                $attr = self::build_html_attribute($option['attributes']);
            else
                $attr = trim(strval($option['attributes']));
        }
        if (strlen($attr))
            $attr = ' ' . $attr;
        $url = self::getPageUrl($pagename, $params);
        return sprintf('<a href="%s"%s>%s</a>', $url, $attr, $Text);
    }

    static function getCmdLink($cmdname, $Text, $option = array('attributes'=>array(),'params'=>array()))
    {
        global $script;
        $params = array('cmd'=>$cmdname);
        $q = '';
        if (isset($option['params']))
        {
            if (is_array($option['params']))
                $params = array_merge($params, $option['params']);
            else
                $q = trim(strval($option['params']));
        }
        if (strlen($q) > 0)
            $q .= '&';
        $q = http_build_query($params) . $q;
        $attr = '';
        if (isset($option['attributes']))
        {
            if (is_array($option['attributes']))
                $attr = self::build_html_attribute($option['attributes']);
            else
                $attr = trim(strval($option['attributes']));
        }
        if (strlen($attr))
            $attr = ' ' . $attr;
        $url = $script . '?' . $q;
        return sprintf('<a href="%s"%s>%s</a>', $url, $attr, $Text);
    }

    static function build_html_attribute($attributes = array())
    {
        $s = array();
        foreach ($attributes as $key=>$value)
        {
            if (!isset($key))
                continue;
            $item = array(htmlentities($key));
            if (isset($value))
                $item .= sprintf('="%s"', htmlentities($value, ENT_QUOTES));
            if (strlen($item))
                $s[] = $item;
        }
        return implode(' ', $s);
    }

    static function urlencode_pagename($pagename)
    {
        return preg_replace_callback('#[^/:]#',
                function ($m) { return rawurlencode($m[0]); },
                (string) $pagename);
    }

    static function LinkUnfreeze($pagename , $options = array('attributes'=>array(),'params'=>array()))
    {
        global $_msg_unfreeze;
        $options['params']['page'] = $pagename;
        return self::getCmdLink('unfreeze', $_msg_unfreeze, $options);
    }

    static function getUrlUnfreeze($pagename , $options = array('params'=>array()))
    {
        $options['params']['page'] = $pagename;
        return self::getCmdUrl('unfreeze', $options['params']);
    }
}