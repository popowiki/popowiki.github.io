<?php

// popologin.inc.php
// Copyright (c) 2016 popowiki
/**/

function plugin_popologin_convert()
{
    global $script, $vars, $_LANG, $user;
    static $id = 0;

    if ( PKWK_READONLY )
        return ''; // Show nothing

    if (is_object($user) && $user->isLoggedIn())
    {
        $s_logout = (isset($_LANG['skin']['m_logout'])? $_LANG['skin']['m_logout'] : 'Logout');
        return sprintf('<a href="%s?cmd=logout">%s</a>', $script, HtmlUtils::escapeHTML($s_logout));
    }

    $v_page = HtmlUtils::escapeHTML(isset($vars['refer']) ? $vars['refer'] : $vars['page']);
    $v_loginid = htmlentities(isset($vars['loginid']) ? $vars['loginid'] : '');
    $v_passwd = htmlentities(isset($vars['password']) ? $vars['password'] : '');
    ++$id;

    $s_login = (isset($_LANG['skin']['m_login']) ? $_LANG['skin']['m_login'] : 'login');
    $s_login_id = (isset($_LANG['skin']['m_loginid']) ? $_LANG['skin']['m_loginid'] : 'login id');
    $s_login_password = (isset($_LANG['skin']['m_password']) ? $_LANG['skin']['m_password'] : 'password');


    $ret = <<<EOD
<form action="$script" method="post">
 <div>
  <input type="hidden" name="plugin" value="popologin" />
  <input type="hidden" name="refer"  value="$v_page" />
    <label>$s_login_id:</label>
    <input type="text"   name="loginid" value="${v_loginid}" size="30" />
    <br />
    <label>$s_login_password:</label>
    <input type="password"   name="password" value="${v_passwd}" size="30" />
  <input type="submit" value="$s_login" />
 </div>
</form>
EOD;

    return $ret;
}

function plugin_popologin_action()
{
    global $vars, $user, $_LANG;

    if ( PKWK_READONLY )
        die_message('PKWK_READONLY prohibits editing');

    $retvars = array('msg' =>'', 'body'=>'');
    $goConvert = true;
    if (!is_object($user) || !$user->isLoggedIn())
        {
            // try login
            if (isset($_POST['loginid']) && ($vars['loginid'] != '') && $user)
            {
                // check ip
                // User::checkAllowedHost()
                // check login
                $text_loginfailed = isset($_LANG['skin']['m_loginfailed'])?$_LANG['skin']['m_loginfailed']:'login failure';

                if (!popowiki\core\User::checkAllowedHost())
                {
                    $ip = (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '?');
                    $host = (isset($_SERVER['REMOTE_HOST']) ? $_SERVER['REMOTE_HOST'] : gethostbyaddr($_SERVER['REMOTE_ADDR']));
                    $retvars['msg'] = 'login not allowed';
                    $retvars['body'] = '<p style="font-size:large; font-weight:bold">login not allowed</p>'
                                   . sprintf('Host Name: %s<br />Host IP Address: %s',
                                          HtmlUtils::escapeHTML($host),
                                          HtmlUtils::escapeHTML($ip));
                    usleep(100*1000);
                    return $retvars;
                }
                else if ($user->login($vars['loginid'], $vars['password']))
                {
                    $goConvert = false;
                }
                else
                {
                    usleep(100*1000);
                    $retvars['body'] .= '<p>' . $text_loginfailed . '</p>';
                    if ($user->invalid_passwd)
                    {
                        $ip = (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '?');
                        $host = (isset($_SERVER['REMOTE_HOST']) ? $_SERVER['REMOTE_HOST'] : gethostbyaddr($_SERVER['REMOTE_ADDR']));
                        $retvars['body'] .= sprintf('<p>Host Name: %s<br />Host IP Address: %s</p>',
                                          HtmlUtils::escapeHTML($host),
                                          HtmlUtils::escapeHTML($ip));
                    }
                }
            }

        }
    if ( $goConvert )
    {
        global $_LANG;
        $s_login = (isset($_LANG['skin']['m_login']) ? $_LANG['skin']['m_login'] : 'login');
        $retvars['msg'] = HtmlUtils::escapeHTML($s_login) . ' ' . $retvars['msg'];
        $retvars['body'] .= plugin_popologin_convert();
        return $retvars;
    }
    else
    {
        $url = get_script_uri();
        if (isset($vars['refer']) && $vars['refer'] !=='')
        {
            $r_page = popowiki\core\Link::urlencode_pagename($vars['refer']);
            $url .= sprintf('?cmd=read&page=%s', $r_page);
        }

        pkwk_headers_sent();
        header('Location: ' . $url);
        exit;
    }
}

function plugin_popologin_allow_no_login()
{
    return TRUE;
}