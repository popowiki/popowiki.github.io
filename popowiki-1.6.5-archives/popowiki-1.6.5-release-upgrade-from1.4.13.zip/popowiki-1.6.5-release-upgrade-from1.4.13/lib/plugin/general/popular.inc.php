<?php

// PukiWiki - Yet another WikiWikiWeb clone
// $Id: popular.inc.php,v 1.20 2011/01/25 15:01:01 henoheno Exp $
// Copyright (C)
//   2003-2005, 2007 PukiWiki Developers Team
//   2002 Kazunori Mizushima <kazunori@uc.netyou.jp>
// License: WHERE IS THE RECORD?
//
// Popular pages plugin: Show an access ranking of this wiki
// -- like recent plugin, using counter plugin's count --
/**/

/*
 * 通算および今日に別けて一覧を作ることができます。
 *
 * [Usage]
 *   #popular
 *   #popular(,,today)
 *   #popular(20,,today)
 *   #popular(20)
 *   #popular(20,FrontPage|MenuBar)
 *   #popular(20,FrontPage|MenuBar[,today|yesterday|total|false|true])
 *
 * [Arguments]
 *   1 - 表示する件数                            default 10
 *   2 - 表示させないページの正規表現             default なし
 *   3 - 表示モードの種類 : 既定値　通算
 *        通算: total ,  false
 *        今日: today ,  true
 *        昨日: yesterday
 *       false,trueは、データの互換性のため
 */

define('PLUGIN_POPULAR_DEFAULT', 10);
define('PLUGIN_POPULAR_MAX', 100);
define('PLUGIN_POPULAR_NO_LIMIT', 0);

// define('PLUGIN_POPULAR_NO_YESTERDAY', TRUE);

//define('PLUGIN_POPULAR_UNDEFINED_ALIAS_AS_BOOL', TRUE);
if (! defined('PLUGIN_POPULAR_UNDEFINED_ALIAS_AS_BOOL'))
 define('PLUGIN_POPULAR_UNDEFINED_ALIAS_AS_BOOL', FALSE);

// Todo: avoid DOS attack

function plugin_popular_convert()
{
    global $vars;
    global $_popular_plugin_frames , $_popular_plugin_alias_to_mode;

    $max = PLUGIN_POPULAR_DEFAULT;
    $except = '';

    $args = func_get_args();
    $num_args = func_num_args();
    $today = get_date('Y/m/d'); // set default value : Total is set to FALSE
    $int_recent_day = intval(get_date('Ymd'), UTIME-7*24*60*60); // 1weeks : 7*24*60*60=86400
    $yesterday = get_date('Y/m/d', UTIME - 86400); // 24*60*60=86400
    $view_mode = 'total'; // set default value

    $unsafe_user_mode = (($num_args >= 3) ? trim((string) $args[2]) : '');

//    $compat_keys = array('true','false');
    $allow_keys  = array('total','today','yesterday');
    if ( isset($_popular_plugin_alias_to_mode) )
    {
       $allow_keys = array_merge($allow_keys , array_keys($_popular_plugin_alias_to_mode));
       if ( ($num_args >= 3) && isset($_popular_plugin_alias_to_mode[$unsafe_user_mode]) )
          $unsafe_user_mode = $_popular_plugin_alias_to_mode[$unsafe_user_mode];
    }
    $pat = implode ('|', array_values($allow_keys) ) . '|false|true';
    $extra_pat = '|recent';

    $pattern = '\s*|' . $pat.$extra_pat; // false|true for pukiwiki
//    $pattern .= '|0|1';
    if ( ! PLUGIN_POPULAR_UNDEFINED_ALIAS_AS_BOOL )
     if (($num_args >= 3) && (! preg_match('/^('. $pattern .')$/i' , $unsafe_user_mode)))
       return sprintf('<div>#popular(invalid  param3 [,' . $pat . '])</div>');

    switch ( min($num_args,3) )
    {
        case 3:
            $flag = strtolower( $unsafe_user_mode );
            // pukiwiki compatible : empty or false
            if ('' !== $flag)
            {
                switch ( $flag )
                {
                    case 'false':
                    case '0':
                    case 'total':
                      $view_mode = 'total';
                      break;

                    case '1':
                    case 'true':
                    case 'today':
                      $view_mode = 'today';
                      break;
                  
                    case 'yesterday':
                      $view_mode = 'yesterday';
                      break;

                    case 'recent':
                      $view_mode = 'recent';
                      break;

                  default :
                      if ( PLUGIN_POPULAR_UNDEFINED_ALIAS_AS_BOOL )
                      {
                          if ($flag)
                            $view_mode = 'today';
                      }
                    break;
                }
            }
        case 2: $except = $args[1];
        case 1:
            if ($args[0] === '')
              $max = PLUGIN_POPULAR_DEFAULT;
             else
              $max = max(0, (int) $args[0]);
    }

    if ( defined('PLUGIN_POPULAR_NO_YESTERDAY') && PLUGIN_POPULAR_NO_YESTERDAY && $view_mode == 'yesterday')
        return '<div>#popular(disabled yesterday)</div>';

    if ( !PLUGIN_POPULAR_NO_LIMIT )
        $max = min($max, PLUGIN_POPULAR_MAX); // limit


    $counters = array();
    if ( $max )
    {
        foreach ( get_existpages(COUNTER_DIR, '.count') as $file => $page )
        {
            if ( ($except != '' && preg_match('/' . $except . '/', $page)) || is_cannot_edit($page) || check_non_list($page) || (!is_page($page))
            )
                continue;

            $lines = file(COUNTER_DIR . $file);
            $count = rtrim($lines[0]);
            $date = rtrim($lines[1]);
            $today_count = rtrim($lines[2]);
            $yesterday_count = intval(rtrim($lines[3]));

            // $pageが数値に見える(たとえばencode('BBS')=424253)とき、
            // array_splice()によってキー値が変更されてしまうのを防ぐ
            // ため、キーに '_' を連結する
            switch ( $view_mode )
            {
                case 'today':
                    if ( $today == $date )
                        $counters['_' . $page] = $today_count;
                    break;
                case 'yesterday':
                    if ( $today == $date )
                        $counters['_' . $page] = $yesterday_count;
                     else if ( $yesterday == $date )
                        $counters['_' . $page] = $today_count;
                    break;
                case 'recent':
                    if ($int_recent_day < intval(str_replace('/', '', $date)) )
                    {
                        $i = intval($today_count) + intval($yesterday_count);
                        if ($i > 0)
                           $counters['_' . $page] = $i;
                    }
                    break;
                case 'total':
                default:
                    $counters['_' . $page] = $count;
                    break;
            }
        }

        asort($counters, SORT_NUMERIC);

        // [[pukiwiki.dev:BugTrack2/106]]: Only variables can be passed by reference from PHP 5.0.5
        $counters = array_reverse($counters, TRUE); // with array_splice()
        $counters = array_splice($counters, 0, $max);
    }

    $items = '';
    if ( !empty($counters) )
    {
        $items = '<ul class="popular_list">' . "\n";

        foreach ( $counters as $page => $count )
        {
            $page = substr($page, 1);

            $s_page = HtmlUtils::escapeHTML($page);
            if ( $page === $vars['page'] )
            {
                // No need to link itself, notifies where you just read
                $pg_passage = get_pg_passage($page, FALSE);
                $items .= ' <li><span title="' . $s_page . ' ' . $pg_passage . '">' .
                        $s_page . '<span class="counter">(' . $count .
                        ')</span></span></li>' . "\n";
            }
            else
            {
                $items .= ' <li>' . make_pagelink($page, $s_page . '<span class="counter">(' . $count . ')</span>') .
                        '</li>' . "\n";
            }
        }
        $items .= '</ul>' . "\n";
    }

    if ( isset($_popular_plugin_frames) && isset($_popular_plugin_frames[$view_mode]) )
          return sprintf( $_popular_plugin_frames[$view_mode] , count($counters), $items);
        else
          return sprintf('<h5>%s(%d)</h5><div>%s</div>' , $view_mode=='total' ? 'popular' : $view_mode."'s" , count($counters), $items);

}

function plugin_popular_allow_no_login()
{
    return TRUE;
}