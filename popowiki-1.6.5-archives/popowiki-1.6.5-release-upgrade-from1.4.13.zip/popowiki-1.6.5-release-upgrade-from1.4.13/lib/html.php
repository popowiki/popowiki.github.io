<?php

/*
 * PopoWiki   PHP Web Wiki System
 * Copyright (C) 2014-2019 PopoWiki Project
 *
// PukiWiki - Yet another WikiWikiWeb clone.
// $Id: html.php,v 1.66 2011/01/25 15:01:01 henoheno Exp $
// Copyright (C)
//   2002-2007 PukiWiki Developers Team
//   2001-2002 Originally written by yu-ji
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * (see licenses/ for more info)
 */
// HTML-publishing related functions
/**/

// Show page-content
function catbody( $title, $page, $body )
{
    global $script, $vars, $arg, $defaultpage, $whatsnew, $help_page, $hr;
    global $attach_link, $related_link, $function_freeze;
    global $search_word_color, $_msg_word, $foot_explain, $note_hr, $head_tags;
    global $javascript, $nofollow;
    global $_LANG, $_LINK, $_IMAGE;
    global $deny_plugin_no_login;


    global $pkwk_dtd;     // XHTML 1.1, XHTML1.0, HTML 4.01 Transitional...
    global $page_title;   // Title of this site
    global $do_backup;    // Do backup or not
    global $modifier;     // Site administrator's  web page
    global $modifierlink; // Site administrator's name

    if ( !file_exists(SKIN_FILE) || !is_readable(SKIN_FILE) )
        die_message('SKIN_FILE is not found');

    $_LINK = $_IMAGE = array();

    // Add JavaScript header when ...
    if ( !PKWK_ALLOW_JAVASCRIPT )
        unset($javascript);

    // set to default when not defined value
    foreach(array('PKWK_HIDE_HELP_MENU', 'PKWK_HIDE_RSS_MENU', 'PKWK_HIDE_LOGIN_MENU') as $v)
        try_define($v, 0);

    $_page = isset($vars['page']) ? $vars['page'] : '';
    $r_page = popowiki\core\Link::urlencode_pagename($_page);

    // Set $_LINK for skin
    $_LINK['add'] = "$script?cmd=add&amp;page=$r_page";
    $_LINK['backup'] = "$script?cmd=backup&amp;page=$r_page";
    $_LINK['copy'] = "$script?plugin=template&amp;refer=$r_page";
    $_LINK['diff'] = "$script?cmd=diff&amp;page=$r_page";
    $_LINK['edit'] = "$script?cmd=edit&amp;page=$r_page";
    $_LINK['delete'] = "$script?cmd=edit&amp;page=${r_page}&delete";
    $_LINK['filelist'] = "$script?cmd=filelist";
    $_LINK['freeze'] = "$script?cmd=freeze&amp;page=$r_page";
    $_LINK['help'] = "$script?" . popowiki\core\Link::urlencode_pagename($help_page);
    $_LINK['home'] = "$script?" . popowiki\core\Link::urlencode_pagename($defaultpage);
    $_LINK['list'] = "$script?cmd=list";
    $_LINK['new'] = "$script?plugin=newpage&amp;refer=$r_page";
    $_LINK['rdf'] = "$script?cmd=rss&amp;ver=1.0";
    $_LINK['recent'] = "$script?" . popowiki\core\Link::urlencode_pagename($whatsnew);
    $_LINK['reload'] = "$script?$r_page";
    $_LINK['rename'] = "$script?plugin=rename&amp;refer=$r_page";
    $_LINK['rss'] = "$script?cmd=rss";
    $_LINK['rss10'] = "$script?cmd=rss&amp;ver=1.0"; // Same as 'rdf'
    $_LINK['rss20'] = "$script?cmd=rss&amp;ver=2.0";
    $_LINK['search'] = "$script?cmd=search";
    $_LINK['top'] = "$script?" . popowiki\core\Link::urlencode_pagename($defaultpage);
    $_LINK['unfreeze'] = "$script?cmd=unfreeze&amp;page=$r_page";
    $_LINK['upload'] = "$script?plugin=attach&amp;pcmd=upload&amp;page=$r_page";

    $_LINK['login'] = "$script?plugin=popologin".($r_page ? sprintf('&refer=%s', $r_page) : '');
    $_LINK['logout'] = "$script?plugin=logout";

    // Compat: Skins for 1.4.4 and before
    $link_add = & $_LINK['add'];
    $link_new = & $_LINK['new']; // New!
    $link_edit = & $_LINK['edit'];
    $link_delete = & $_LINK['delete'];
    $link_diff = & $_LINK['diff'];
    $link_top = & $_LINK['top'];
    $link_home = & $_LINK['home'];
    $link_list = & $_LINK['list'];
    $link_filelist = & $_LINK['filelist'];
    $link_search = & $_LINK['search'];
    $link_whatsnew = & $_LINK['recent'];
    $link_backup = & $_LINK['backup'];
    $link_help = & $_LINK['help'];
    $link_trackback = ''; // Removed (compat)
    $link_rdf = & $_LINK['rdf'];  // New!
    $link_rss = & $_LINK['rss'];
    $link_rss10 = & $_LINK['rss10'];  // New!
    $link_rss20 = & $_LINK['rss20'];  // New!
    $link_freeze = & $_LINK['freeze'];
    $link_unfreeze = & $_LINK['unfreeze'];
    $link_upload = & $_LINK['upload'];
    $link_template = & $_LINK['copy'];
    $link_refer = ''; // Removed (compat)
    $link_rename = & $_LINK['rename'];

    $link_login = & $_LINK['login'];
    $link_logout = & $_LINK['logout'];

    global $user, $is_loggedin;
    $is_loggedin = (isset($user) && $user->isLoggedIn());

    // Init flags
    $is_page = (is_pagename($_page) && !arg_check('backup') && !is_cannot_edit($_page));
    $is_read = (arg_check('read') && is_page($_page));
    $is_freeze = is_freeze($_page);

    // Last modification date (string) of the page
    $lastmodified = $is_read ? format_date(get_filetime($_page)) .
            ' ' . get_pg_passage($_page, FALSE) : '';

    // List of attached files to the page
    $attaches = ($attach_link && $is_read && exist_plugin_action('attach')) ?
            attach_filelist() : '';

    // List of related pages
    $related = ($related_link && $is_read) ? make_related($_page) : '';

    // List of footnotes
    ksort($foot_explain, SORT_NUMERIC);
    $notes = !empty($foot_explain) ? $note_hr . join("\n", $foot_explain) : '';

    // Tags will be inserted into <head></head>
    $head_tag = !empty($head_tags) ? join("\n", $head_tags) . "\n" : '';

    // 1.3.x compat
    // Last modification date (UNIX timestamp) of the page
    $fmt = $is_read ? get_filetime($_page) + LOCALZONE : 0;

    // Search words
    if ( $search_word_color && isset($vars['word']) )
    {
        $body = '<div class="small">' . $_msg_word . HtmlUtils::escapeHTML($vars['word']) .
                '</div>' . $hr . "\n" . $body;

        // [[pukiwiki.dev:BugTrack2/106]]: Only variables can be passed by reference from PHP 5.0.5
        // with array_splice(), array_flip()
        $words = preg_split('/\s+/', $vars['word'], -1, PREG_SPLIT_NO_EMPTY);
        $words = array_splice($words, 0, 10); // Max: 10 words
        $words = array_flip($words);

        $keys = array();
        foreach ( $words as $word => $id )
            $keys[$word] = strlen($word);
        arsort($keys, SORT_NUMERIC);
        $keys = get_search_words(array_keys($keys), TRUE);
        $id = 0;
        foreach ( $keys as $key => $pattern )
        {
            $s_key = HtmlUtils::escapeHTML($key);
            $pattern = '/' .
                    '<textarea[^>]*>.*?<\/textarea>' . // Ignore textareas
                    '|' . '<[^>]*>' . // Ignore tags
                    '|' . '&[^;]+;' . // Ignore entities
                    '|' . '(' . $pattern . ')' . // $matches[1]: Regex for a search word
                    '/sS';
            $decorate_Nth_word = function ($matches) use($id) {
                    if (isset($matches[1]))
                      return sprintf('<strong class="word%d">%s</strong>', $id, $matches[1]);
                    return $matches[0];
                };
            $body = preg_replace_callback($pattern, $decorate_Nth_word, $body);
            $notes = preg_replace_callback($pattern, $decorate_Nth_word, $notes);
            ++$id;
        }
    }
    
    
// start $navi_link_keys_for_user
    global $navi_link_keys_for_user;
    $navi_link_keys_for_user = array();

    $navi_link_keys_for_user[] = 'home';
    $navi_link_keys_for_user[] = 'top';
    if ( $is_page )
    {
        if ( ! PKWK_READONLY && $is_loggedin)
        {
            $navi_link_keys_for_user[] = 'add';
            $navi_link_keys_for_user[] = 'edit';
            if ( $is_read && $function_freeze )
            {
                if ( !$is_freeze )
                    $navi_link_keys_for_user[] = 'freeze';
                else
                    $navi_link_keys_for_user[] = 'unfreeze';
            }
            if ( (bool) ini_get('file_uploads') )
            {
                $navi_link_keys_for_user[] = 'upload';
            }
            $navi_link_keys_for_user[] = 'copy';
            $navi_link_keys_for_user[] = 'delete';
            $navi_link_keys_for_user[] = 'rename';
        }
        if ($is_loggedin)
        {
            $navi_link_keys_for_user[] = 'diff';
        }

        if ( $do_backup && $is_loggedin)
        {
            $navi_link_keys_for_user[] = 'backup';
        }
        if ($is_loggedin)
        {
            $navi_link_keys_for_user[] = 'reload';
        }
    }

    if ( ! PKWK_READONLY && $is_loggedin)
    {
        $navi_link_keys_for_user[] = 'new';
    }

    if ( $is_loggedin || (!$is_loggedin && !in_array('list', $deny_plugin_no_login)) )
        $navi_link_keys_for_user[] = 'list';

    if ( arg_check('list') && $is_loggedin)
    {
        $navi_link_keys_for_user[] = 'filelist';
    }

    if ( $is_loggedin || (!$is_loggedin && !in_array('search', $deny_plugin_no_login)) )
        $navi_link_keys_for_user[] = 'search';

    if ($is_loggedin)
    {
        $navi_link_keys_for_user[] = 'recent';
    }
    
    if ( $is_loggedin || (!$is_loggedin && !PKWK_HIDE_HELP_MENU) )
        $navi_link_keys_for_user[] = 'help';

    if ( $is_loggedin || (!$is_loggedin && !PKWK_HIDE_RSS_MENU) )
    {
        $navi_link_keys_for_user[] = 'rss';    // RSS 0.91
        $navi_link_keys_for_user[] = 'rss10';  // RSS 1.0
        $navi_link_keys_for_user[] = 'rss20';  // RSS 2.0
        $navi_link_keys_for_user[] = 'rdf';    //
    }

    if ( $is_loggedin || (!$is_loggedin && !PKWK_HIDE_LOGIN_MENU) )
        $navi_link_keys_for_user[] = !$is_loggedin ? 'login' : 'logout';     //

    // Todo: login or not
    // Todo: admin can disable each value manually
    //
//  end $navi_link_keys_for_user
    
    
    // Compat: 'HTML convert time' without time about MenuBar and skin
    $taketime = elapsedtime();

    require(SKIN_FILE);
}

// Show 'edit' form
function edit_form( $page, $postdata, $digest = FALSE, $b_template = TRUE )
{
    return edit_formEx($page, $postdata, $digest, $b_template);
}

function edit_form_section( $page, $postdata, $section_id, $body_array, $digest = FALSE, $b_template = TRUE )
{
    $options = array('digest' >= $digest, 'b_template'=>$b_template);
    $options['section_id'] = max(0, intval($section_id));
    $options['body'] =& $body_array;
    return edit_formEx($page, $postdata, $options);
}

// section_id, selection_start, selection_end
//
function edit_formEx( $page, $postdata, $options = array('digest' >= FALSE, 'b_template'=>TRUE))
{
    global $script, $vars, $rows, $cols, $hr, $function_freeze;
    global $_btn_preview, $_btn_repreview, $_btn_update, $_btn_cancel, $_msg_help;
    global $_btn_template, $_btn_load, $load_template_func;
    global $notimeupdate;

    $digest = FALSE;
    $b_template = TRUE;
    $section = 0;
    if (isset($options['digest']))
        $digest = $options['digest'];
    if (isset($options['b_template']))
        $b_template = $options['b_template'];
    if (isset($options['section_id']))
        $section = max(0, intval($options['section_id']));

    // Newly generate $digest or not
    if ( $digest === FALSE )
        $digest = md5(get_source($page, TRUE, TRUE));

    $refer = $template = '';

    // Add plugin
    $addtag = $add_top = '';
    if ( isset($vars['add']) )
    {
        global $_btn_addtop;
        $addtag = '<input type="hidden" name="add"    value="true" />';
        $add_top = isset($vars['add_top']) ? ' checked="checked"' : '';
        $add_top = '<input type="checkbox" name="add_top" ' .
                'id="_edit_form_add_top" value="true"' . $add_top . ' />' . "\n" .
                '  <label for="_edit_form_add_top">' .
                '<span class="small">' . $_btn_addtop . '</span>' .
                '</label>';
    }

    if ( $load_template_func && $b_template )
    {
        $pages = array();
        foreach ( get_existpages() as $_page )
        {
            if ( is_cannot_edit($_page) || check_non_list($_page) || (!check_readable($_page, false, false)) )
                continue;
            $s_page = HtmlUtils::escapeHTML($_page);
            $pages[$_page] = '   <option value="' . $s_page . '">' .
                    $s_page . '</option>';
        }
        ksort($pages, SORT_STRING);
        $s_pages = join("\n", $pages);
        $template = <<<EOD
  <select name="template_page">
   <option value="">-- $_btn_template --</option>
$s_pages
  </select>
  <input type="submit" name="template" value="$_btn_load" accesskey="r" />
  <br />
EOD;

        if ( isset($vars['refer']) && $vars['refer'] != '' )
            $refer = '[[' . strip_bracket($vars['refer']) . ']]' . "\n\n";
    }

    $r_page = popowiki\core\Link::urlencode_pagename($page);
    $s_page = HtmlUtils::escapeHTML($page);
    $s_digest = HtmlUtils::escapeHTML($digest);
    $s_postdata = HtmlUtils::escapeHTML($refer . $postdata);
    $s_original = isset($vars['original']) ? HtmlUtils::escapeHTML($vars['original']) : $s_postdata;
    $b_preview = isset($vars['preview']); // TRUE when preview
    $btn_preview = $b_preview ? $_btn_repreview : $_btn_preview;

    // Checkbox 'do not change timestamp'
    $add_notimestamp = '';
    if ( $notimeupdate != 0 )
    {
        global $_btn_notchangetimestamp;
        $checked_time = isset($vars['notimestamp']) ? ' checked="checked"' : '';
        // Only for administrator
        if ( $notimeupdate == 2 )
        {
            $add_notimestamp = '   ' .
                    '<input type="password" name="pass" size="20" />' . "\n";
        }
        $add_notimestamp = '<input type="checkbox" name="notimestamp" ' .
                'id="_edit_form_notimestamp" value="true"' . $checked_time . ' />' . "\n" .
                '   ' . '<label for="_edit_form_notimestamp"><span class="small">' .
                $_btn_notchangetimestamp . '</span></label>' . "\n" .
                $add_notimestamp .
                '&nbsp;';
    }

    if ($section > 0)
    {
        $section_msg0 = ( is_array($options['body'][0]) ? implode('', $options['body'][0]) : $options['body'][0]);
        $section_msg1 = ( is_array($options['body'][1]) ? implode('', $options['body'][1]) : $options['body'][1]);
        $section_msg2 = ( is_array($options['body'][2]) ? implode('', $options['body'][2]) : $options['body'][2]);
        if (!isset($options['body'][3]))
        {
            $section_msg0 = bin2hex(zlib_encode($section_msg0, ZLIB_ENCODING_DEFLATE));
            $section_msg1 = bin2hex(zlib_encode($section_msg1, ZLIB_ENCODING_DEFLATE));
            $section_msg2 = bin2hex(zlib_encode($section_msg2, ZLIB_ENCODING_DEFLATE));
        }

        $tag_section = array();
        $tag_section[] = sprintf('<input type="hidden" name="section" value="%d" />', $section);
        $tag_section[] = sprintf('<input type="hidden" name="section_msg0" value="%s" />', $section_msg0);
        $tag_section[] = sprintf('<input type="hidden" name="section_msg1" value="%s" />', $section_msg1);
        $tag_section[] = sprintf('<input type="hidden" name="section_msg2" value="%s" />', $section_msg2);
        $addtag .= "\n" . implode("\n", $tag_section);

        $s_original = '';
    }
    // todo: deprecated: name="original"
    //       replace to selection_src
    // todo: section replace to selection
    //       replace to selection, selection_src , selection_start, selection_end

    // 'margin-bottom', 'float:left', and 'margin-top'
    // are for layout of 'cancel button'
    $body = <<<EOD
<div class="edit_form">
 <form action="$script" method="post" style="margin-bottom:0px;">
$template <pptoolbar />
  $addtag
  <input type="hidden" name="cmd"    value="edit" />
  <input type="hidden" name="page"   value="$s_page" />
  <input type="hidden" name="digest" value="$s_digest" />
  <textarea name="msg" rows="$rows" cols="$cols">$s_postdata</textarea>
  <br />
  <div style="float:left;">
   <input type="submit" name="preview" value="$btn_preview" accesskey="p" />
   <input type="submit" name="write"   value="$_btn_update" accesskey="s" />
   $add_top
   $add_notimestamp
  </div>
  <textarea name="original" rows="1" cols="1" style="display:none">$s_original</textarea>
 </form>
 <form action="$script" method="post" style="margin-top:0px;">
  <input type="hidden" name="cmd"    value="edit" />
  <input type="hidden" name="page"   value="$s_page" />
  <input type="submit" name="cancel" value="$_btn_cancel" accesskey="c" />
 </form>
</div>
EOD;

    $toolbar = '';
    $pp_script = array();
    $pp_editor_mode = 'popo';
    switch ( $pp_editor_mode )
    {
//        case 'ckeditor': break; // not worked
//            $ed_url = POPOWIKI_SKIN_URI . 'js/ckeditor/ckeditor.js';
//            if ( file_exists($ed_url) )
//                $ed_url = '/' . $ed_url;
//               else
//                $ed_url = '//cdn.ckeditor.com/4.4.7/standard/ckeditor.js';
//            $pp_script[] = "<script src='$ed_url'></script>";
//            $pp_script[] = "<script>  CKEDITOR.replace( 'msg' , { language: 'ja', uiColor: '#9AB8F3' } );  </script>";
//            break;
//        case 'tinymce': break; // not worked
//            $pp_script[] = '<script src="//tinymce.cachefly.net/4.1/tinymce.min.js"></script>' .
//            $pp_script[] = "<script>tinymce.init({selector:'textarea'});</script>";
//            break;
//        case 'jquery': break; // not worked
//            $pp_script[] =  "<script src='/". POPOWIKI_SKIN_URI ."js/jquery.min.js'></script>".$body;
//            break;
        default:
            include_once LIB_DIR . 'popo_editor.php';
            $toolbar = "<div>" . get_js_popo_editor_toolbar() . "</div>";
//          $pp_script[] = "<script src='". POPOWIKI_SKIN_URI ."js/jquery.min.js'></script>";
            $pp_script[] = "<script src='". POPOWIKI_SKIN_URI ."js/popo_editor.js'></script>";
            break;
    }
    $body = implode("\n",$pp_script) . str_replace('<pptoolbar />', $toolbar , $body);

    if ( isset($vars['help']) )
    {
        $body .= $hr . catrule();
    }
    else
    {
        $body .= '<ul><li><a href="' .
                $script . '?cmd=edit&amp;help=true&amp;page=' . $r_page .
                '">' . $_msg_help . '</a></li></ul>';
    }

    return $body;
}

// Related pages
function make_related( $page, $tag = '' )
{
    global $script, $vars, $rule_related_str, $related_str;
    global $_ul_left_margin, $_ul_margin, $_list_pad_str;

    $links = links_get_related($page);

    if ( $tag )
    {
        ksort($links, SORT_STRING);  // Page name, alphabetical order
    }
    else
    {
        arsort($links, SORT_NUMERIC); // Last modified date, newer
    }

    global $defaultpage,$whatsnew,$whatsdeleted,$interwiki,$aliaspage,$menubar,$MenuBar_Right;
    $exclude_list = array();
    foreach( @array($defaultpage,$whatsnew,$whatsdeleted,$interwiki,$aliaspage,$menubar,$MenuBar_Right,$MenuBar_Right['menu_pagename'])
            as $v)
       if (@strlen($v)>0)
           $exclude_list[] = $v;

    $_links = array();
    foreach ( $links as $page => $lastmod )
    {
        if ( check_non_list($page) )
            continue;
        if ( in_array($page, $exclude_list) )
            continue;

        $r_page = popowiki\core\Link::urlencode_pagename($page);
        $s_page = HtmlUtils::escapeHTML($page);
        $passage = get_passage($lastmod);
        $_links[] = $tag ?
                '<a href="' . $script . '?' . $r_page . '" title="' .
                $s_page . ' ' . $passage . '">' . $s_page . '</a>' :
                '<a href="' . $script . '?' . $r_page . '">' .
                $s_page . '</a>' . $passage;
    }
    if ( empty($_links) )
        return ''; // Nothing

    if ( $tag == 'p' )
    { // From the line-head
        $margin = $_ul_left_margin + $_ul_margin;
        $style = sprintf($_list_pad_str, 1, $margin, $margin);
        $retval = "\n" . '<ul' . $style . '>' . "\n" .
                '<li>' . join($rule_related_str, $_links) . '</li>' . "\n" .
                '</ul>' . "\n";
    }
    else if ( $tag )
    {
        $retval = join($rule_related_str, $_links);
    }
    else
    {
        $retval = join($related_str, $_links);
    }

    return $retval;
}

// User-defined rules (convert without replacing source)
function make_line_rules( $str )
{
    global $line_rules;
    static $pattern = NULL, $replace = NULL;

    if ( !isset($pattern) )
    {
        $pattern = array_map(function($a) { return '/' . $a . '/'; }, array_keys($line_rules));
        $replace = array_values($line_rules);
        unset($line_rules);
    }

    return preg_replace($pattern, $replace, $str);
}

// Remove all HTML tags(or just anchor tags), and WikiName-speific decorations
function strip_htmltag( $str, $all = TRUE )
{
    global $_symbol_noexists;
    static $noexists_pattern = NULL;

    if ( !isset($noexists_pattern) )
        $noexists_pattern = '#<span class="noexists">([^<]*)<a[^>]+>' .
                preg_quote($_symbol_noexists, '#') . '</a></span>#';

    // Strip Dagnling-Link decoration (Tags and "$_symbol_noexists")
    $str = preg_replace($noexists_pattern, '$1', $str);

    if ( $all )
    {
        // All other HTML tags
        return preg_replace('#<[^>]+>#', '', $str);
    }
    else
    {
        // All other anchor-tags only
        return preg_replace('#<a[^>]+>|</a>#i', '', $str);
    }
}

// Remove AutoLink marker with AutLink itself
function strip_autolink( $str )
{
    return preg_replace('#<!--autolink--><a [^>]+>|</a><!--/autolink-->#', '', $str);
}

// Make a backlink. searching-link of the page name, by the page name, for the page name
function make_search( $page )
{
    global $script;

    $s_page = HtmlUtils::escapeHTML($page);
    $r_page = popowiki\core\Link::urlencode_pagename($page);

    return '<a href="' . $script . '?plugin=related&amp;page=' . $r_page .
            '">' . $s_page . '</a> ';
}

// Make heading string (remove heading-related decorations from Wiki text)
function make_heading( & $str, $strip = TRUE )
{
    global $NotePattern;

    // Cut fixed-heading anchors
    $id = '';
    $matches = array();
    if ( preg_match('/^(\*{0,3})(.*?)\[#([A-Za-z][\w-]+)\](.*?)$/m', $str, $matches) )
    {
        $str = $matches[2] . $matches[4];
        $id = & $matches[3];
    }
    else
    {
        $str = preg_replace('/^\*{0,3}/', '', $str);
    }

    // Cut footnotes and tags
    if ( $strip === TRUE )
    {
        $str = strip_htmltag( make_link(
                   preg_replace( $NotePattern, '' , $str)
                ) );
    }

    return $id;
}

// Separate a page-name(or URL or null string) and an anchor
// (last one standing) without sharp
function anchor_explode( $page, $strict_editable = FALSE )
{
    $pos = strrpos($page, '#');
    if ( $pos === FALSE )
        return array($page, '', FALSE);

    // Ignore the last sharp letter
    if ( $pos + 1 == strlen($page) )
    {
        $pos = strpos(substr($page, $pos + 1), '#');
        if ( $pos === FALSE )
            return array($page, '', FALSE);
    }

    $s_page = substr($page, 0, $pos);
    $anchor = substr($page, $pos + 1);

    if ( $strict_editable === TRUE && preg_match('/^[a-z][a-f0-9]{7}$/', $anchor) )
    {
        return array($s_page, $anchor, TRUE); // Seems fixed-anchor
    }
    else
    {
        return array($s_page, $anchor, FALSE);
    }
}

// Check HTTP header()s were sent already, or
// there're blank lines or something out of php blocks
function pkwk_headers_sent()
{
    if ( PKWK_OPTIMISE )
        return;

    $file = $line = '';

    if ( headers_sent($file, $line) )
    {
        die('Headers already sent at ' .
                HtmlUtils::escapeHTML($file) .
                ' line ' . $line . '.');
    }
}

// Output common HTTP headers
function pkwk_common_headers()
{
    if ( !PKWK_OPTIMISE )
        pkwk_headers_sent();

    if ( defined('PKWK_ZLIB_LOADABLE_MODULE') )
    {
        $matches = array();
        if ( ini_get('zlib.output_compression') &&
                preg_match('/\b(gzip|deflate)\b/i', $_SERVER['HTTP_ACCEPT_ENCODING'], $matches) )
        {
            // Bug #29350 output_compression compresses everything _without header_ as loadable module
            // http://bugs.php.net/bug.php?id=29350
            header('Content-Encoding: ' . $matches[1]);
            header('Vary: Accept-Encoding');
        }
    }
}

// DTD definitions
define('PKWK_DTD_XHTML_1_1', 17); // Strict only
define('PKWK_DTD_XHTML_1_0', 16); // Strict
define('PKWK_DTD_XHTML_1_0_STRICT', 16);
define('PKWK_DTD_XHTML_1_0_TRANSITIONAL', 15);
define('PKWK_DTD_XHTML_1_0_FRAMESET', 14);
define('PKWK_DTD_HTML_4_01', 3); // Strict
define('PKWK_DTD_HTML_4_01_STRICT', 3);
define('PKWK_DTD_HTML_4_01_TRANSITIONAL', 2);
define('PKWK_DTD_HTML_4_01_FRAMESET', 1);

define('PKWK_DTD_TYPE_XHTML', 1);
define('PKWK_DTD_TYPE_HTML', 0);

// Output HTML DTD, <html> start tag. Return content-type.
function pkwk_output_dtd( $pkwk_dtd = PKWK_DTD_XHTML_1_1, $charset = CONTENT_CHARSET )
{
    static $called = FALSE;
    if ( $called )
        die('pkwk_output_dtd() already called. Why?');
    $called = TRUE;

    $type = PKWK_DTD_TYPE_XHTML;
    $option = '';
    switch ( $pkwk_dtd )
    {
        case PKWK_DTD_XHTML_1_1 :
            $version = '1.1';
            $dtd = 'http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd';
            break;
        case PKWK_DTD_XHTML_1_0_STRICT :
            $version = '1.0';
            $option = 'Strict';
            $dtd = 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd';
            break;
        case PKWK_DTD_XHTML_1_0_TRANSITIONAL:
            $version = '1.0';
            $option = 'Transitional';
            $dtd = 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd';
            break;

        case PKWK_DTD_HTML_4_01_STRICT :
            $type = PKWK_DTD_TYPE_HTML;
            $version = '4.01';
            $dtd = 'http://www.w3.org/TR/html4/strict.dtd';
            break;
        case PKWK_DTD_HTML_4_01_TRANSITIONAL:
            $type = PKWK_DTD_TYPE_HTML;
            $version = '4.01';
            $option = 'Transitional';
            $dtd = 'http://www.w3.org/TR/html4/loose.dtd';
            break;

        default: die('DTD not specified or invalid DTD');
            break;
    }

    $charset = HtmlUtils::escapeHTML($charset);

    // Output XML or not
    if ( $type == PKWK_DTD_TYPE_XHTML )
        echo '<?xml version="1.0" encoding="' . $charset . '" ?>' . "\n";

    // Output doctype
    echo '<!DOCTYPE html PUBLIC "-//W3C//DTD ' .
    ($type == PKWK_DTD_TYPE_XHTML ? 'XHTML' : 'HTML') . ' ' .
    $version .
    ($option != '' ? ' ' . $option : '') .
    '//EN" "' .
    $dtd .
    '">' . "\n";

    // Output <html> start tag
    echo '<html';
    if ( $type == PKWK_DTD_TYPE_XHTML )
    {
        echo ' xmlns="http://www.w3.org/1999/xhtml"'; // dir="ltr" /* LeftToRight */
        echo ' xml:lang="' . LANG . '"';
        if ( $version == '1.0' )
            echo ' lang="' . LANG . '"'; // Only XHTML 1.0
    } else
    {
        echo ' lang="' . LANG . '"'; // HTML
    }
    echo '>' . "\n"; // <html>
    // Return content-type (with MIME type)
    if ( $type == PKWK_DTD_TYPE_XHTML )
    {
        // NOTE: XHTML 1.1 browser will ignore http-equiv
        return '<meta http-equiv="content-type" content="application/xhtml+xml; charset=' . $charset . '" />' . "\n";
    }
    else
    {
        return '<meta http-equiv="content-type" content="text/html; charset=' . $charset . '" />' . "\n";
    }
}

 
