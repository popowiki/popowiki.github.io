<?php

// (c) 2014-2016 popowiki

// PukiWiki - Yet another WikiWikiWeb clone
// $Id: attach.inc.php,v 1.92 2011/01/25 15:01:01 henoheno Exp $
// Copyright (C)
//   2003-2007, 2009 PukiWiki Developers Team
//   2002-2003 PANDA <panda@arino.jp> http://home.arino.jp/
//   2002      Y.MASUI <masui@hisec.co.jp> http://masui.net/pukiwiki/
//   2001-2002 Originally written by yu-ji
// License: GPL v2 or (at your option) any later version
//
// File attach plugin
/**/

plugin_attach_init_constant();

function plugin_attach_init_constant()
{
    // Max file size for upload on script of PukiWikiX_FILESIZE
    if (!defined('PLUGIN_ATTACH_MAX_FILESIZE'))
        define('PLUGIN_ATTACH_MAX_FILESIZE', (1 * 1024 * 1024)); // default: 1MB

    // 管理者だけが添付ファイルをアップロードできるようにする
    if (!defined('PLUGIN_ATTACH_UPLOAD_ADMIN_ONLY'))
        define('PLUGIN_ATTACH_UPLOAD_ADMIN_ONLY', TRUE); // FALSE or TRUE

    // 管理者だけが添付ファイルを削除できるようにする
    if (!defined('PLUGIN_ATTACH_DELETE_ADMIN_ONLY'))
        define('PLUGIN_ATTACH_DELETE_ADMIN_ONLY', TRUE); // FALSE or TRUE

    // 管理者が添付ファイルを削除するときは、バックアップを作らない
    // PLUGIN_ATTACH_DELETE_ADMIN_ONLY=TRUEのとき有効
    if (!defined('PLUGIN_ATTACH_DELETE_ADMIN_NOBACKUP'))
        define('PLUGIN_ATTACH_DELETE_ADMIN_NOBACKUP', TRUE); // FALSE or TRUE

    // アップロード/削除時にパスワードを要求する(ADMIN_ONLYが優先)
    if (!defined('PLUGIN_ATTACH_PASSWORD_REQUIRE'))
        define('PLUGIN_ATTACH_PASSWORD_REQUIRE', FALSE); // FALSE or TRUE

    // 添付ファイル名を変更できるようにする
    if (!defined('PLUGIN_ATTACH_RENAME_ENABLE'))
        define('PLUGIN_ATTACH_RENAME_ENABLE', TRUE); // FALSE or TRUE

    // ファイルのアクセス権
    if (!defined('PLUGIN_ATTACH_FILE_MODE'))
    {
        if( preg_match('#xrea\.com$#', popowiki_getServerName()) )
            define('PLUGIN_ATTACH_FILE_MODE', 0604); // for XREA.COM
        else
            define('PLUGIN_ATTACH_FILE_MODE', 0644);
    }

    // File icon image
    if (!defined('PLUGIN_ATTACH_FILE_ICON'))
        define('PLUGIN_ATTACH_FILE_ICON', '<img src="' . IMAGE_DIR . 'file.png"' .
                ' width="20" height="20" alt="file"' .
                ' style="border-width:0px" />');

    // mime-typeを記述したページ
    if (!defined('PLUGIN_ATTACH_CONFIG_PAGE_MIME'))
        define('PLUGIN_ATTACH_CONFIG_PAGE_MIME', 'plugin/attach/mime-type');
}

//-------- convert
function plugin_attach_convert()
{
    global $vars;

    $page = isset($vars['page']) ? $vars['page'] : '';

    $nolist = $noform = FALSE;
    if ( func_num_args() > 0 )
    {
        foreach ( func_get_args() as $arg )
        {
            $arg = strtolower($arg);
            $nolist |= ($arg == 'nolist');
            $noform |= ($arg == 'noform');
        }
    }

    $ret = '';
    if ( !$nolist )
    {
        $obj = new AttachPages($page);
        $ret .= $obj->toString($page, TRUE);
    }
    if ( !$noform )
    {
        $ret .= attach_form($page);
    }

    return $ret;
}

//-------- action
function plugin_attach_action()
{
    global $vars, $_attach_messages;
    global $user;

    // Backward compatible
    if ( isset($vars['openfile']) )
    {
        $vars['file'] = $vars['openfile'];
        $vars['pcmd'] = 'open';
    }
    if ( isset($vars['delfile']) )
    {
        $vars['file'] = $vars['delfile'];
        $vars['pcmd'] = 'delete';
    }

    $pcmd = isset($vars['pcmd']) ? $vars['pcmd'] : '';
    $refer = isset($vars['refer']) ? $vars['refer'] : '';
    $pass = isset($vars['pass']) ? $vars['pass'] : NULL;
    $page = isset($vars['page']) ? $vars['page'] : '';

    if ( $refer != '' && is_pagename($refer) )
    {
        if ( in_array($pcmd, array('info', 'open', 'list')) )
        {
            check_readable($refer);
        }
        else
        {
            check_editable($refer);
        }
    }

    if ((!$user || !$user->isLoggedIn()) && (!in_array($pcmd, array('info', 'open'))))
        die_message('You are not logged in');

    // Dispatch
    if ( isset($_FILES['attach_file']) )
    {
        // Upload
        return attach_upload($_FILES['attach_file'], $refer, $pass);
    }
    else
    {
        switch ( $pcmd )
        {
            case 'delete': /* FALLTHROUGH */
            case 'freeze':
            case 'unfreeze':
                if ( PKWK_READONLY )
                    die_message('PKWK_READONLY prohibits editing');
        }
        switch ( $pcmd )
        {
            case 'info' : return attach_info();
            case 'delete' : return attach_delete();
            case 'open' : return attach_open();
            case 'list' : return attach_list();
            case 'freeze' : return attach_freeze(TRUE);
            case 'unfreeze' : return attach_freeze(FALSE);
            case 'rename' : return attach_rename();
            case 'upload' : return attach_showform();
        }
        if ( $page == '' || !is_page($page) )
        {
            return attach_list();
        }
        else
        {
            return attach_showform();
        }
    }
}

//-------- call from skin
function attach_filelist()
{
    global $vars, $_attach_messages;

    $page = isset($vars['page']) ? $vars['page'] : '';

    $obj = new AttachPages($page, 0);

    if ( !isset($obj->pages[$page]) )
    {
        return '';
    }
    else
    {
        return $_attach_messages['msg_file'] . ': ' .
                $obj->toString($page, TRUE) . "\n";
    }
}

//-------- 実体
// ファイルアップロード
// $pass = NULL : パスワードが指定されていない
// $pass = TRUE : アップロード許可
function attach_upload( $file, $page, $pass = NULL )
{
    global $_attach_messages, $notify, $notify_subject;

    if ( PKWK_READONLY )
        die_message('PKWK_READONLY prohibits editing');

    // Check query-string
    $query = 'plugin=attach&amp;pcmd=info&amp;refer=' . popowiki\core\Link::urlencode_pagename($page) .
            '&amp;file=' . rawurlencode($file['name']);

    if ( PKWK_QUERY_STRING_MAX && strlen($query) > PKWK_QUERY_STRING_MAX )
    {
        pkwk_common_headers();
        echo('Query string (page name and/or file name) too long');
        exit;
    }
    else if ( !is_page($page) )
    {
        die_message('No such page');
    }
    else if ( $file['tmp_name'] == '' || !is_uploaded_file($file['tmp_name']) )
    {
        $msg = "Error upload : ";
//        $file_uploads   = ini_get('file_uploads');
//        $upload_tmp_dir = ini_get('upload_tmp_dir');
//        $upload_max_filesize = ini_get('upload_max_filesize');
//        if ($upload_tmp_dir === FALSE || $upload_tmp_dir == '')
//            $msg .= "setteing value is empty : see php.ini upload_tmp_dir.";
        $msg .= sprintf("you may be exeeded max size %d", PLUGIN_ATTACH_MAX_FILESIZE);

        return array('result' => FALSE
                    , 'msg' => $msg
                    );
    }
    else if ( $file['size'] > PLUGIN_ATTACH_MAX_FILESIZE )
    {
        return array(
            'result' => FALSE,
            'msg' => $_attach_messages['err_exceed']);
    }
    else if ( !is_pagename($page) || ($pass !== TRUE && !is_editable($page)) )
    {
        return array(
            'result' => FALSE, '
			msg' => $_attach_messages['err_noparm']);
    }
    else if ( PLUGIN_ATTACH_UPLOAD_ADMIN_ONLY && $pass !== TRUE &&
            ($pass === NULL || !pkwk_login($pass)) )
    {
        return array(
            'result' => FALSE,
            'msg' => $_attach_messages['err_adminpass']);
    }

    $obj = new AttachFile($page, $file['name']);
    if ( $obj->exist )
        return array('result' => FALSE,
            'msg' => $_attach_messages['err_exists']);

    if ( move_uploaded_file($file['tmp_name'], $obj->filename) )
    {
        // Todo: file is image or not
        // remove exif info for privacy protection
        $ErrMsg = '';
        $res = AttachFile::checkAndRemoveExif($obj->filename, $ErrMsg);
        if (!$res)
        {
            unlink($obj->filename);
            return array('result' => FALSE,
                         'msg' => $ErrMsg);
        }
        // modify file permission
        chmod($obj->filename, PLUGIN_ATTACH_FILE_MODE);
    }

    if ( is_page($page) )
        pkwk_touch_file(get_filename($page));

    $obj->getstatus();
    $obj->status['pass'] = ($pass !== TRUE && $pass !== NULL) ? md5($pass) : '';
    $obj->putstatus();

    if ( $notify )
    {
        $footer['ACTION'] = 'File attached';
        $footer['FILENAME'] = & $file['name'];
        $footer['FILESIZE'] = & $file['size'];
        $footer['PAGE'] = & $page;

        $footer['URI'] = get_script_uri() .
                //'?' . popowiki\core\Link::urlencode_pagename($page);
                // MD5 may heavy
                '?plugin=attach' .
                '&refer=' . popowiki\core\Link::urlencode_pagename($page) .
                '&file=' . rawurlencode($file['name']) .
                '&pcmd=info';

        $footer['USER_AGENT'] = TRUE;
        $footer['REMOTE_ADDR'] = TRUE;

        pkwk_mail_notify($notify_subject, "\n", $footer) or
                die('pkwk_mail_notify(): Failed');
    }

    return array(
        'result' => TRUE,
        'msg' => $_attach_messages['msg_uploaded']);
}

// 詳細フォームを表示
function attach_info( $err = '' )
{
    global $vars, $_attach_messages;

    foreach ( array('refer', 'file', 'age') as $var )
        ${$var} = isset($vars[$var]) ? $vars[$var] : '';

    $obj = new AttachFile(${'refer'}, ${'file'}, ${'age'});
    return $obj->getstatus() ?
            $obj->info($err) :
            array('msg' => $_attach_messages['err_notfound']);
}

// 削除
function attach_delete()
{
    global $vars, $_attach_messages;

    foreach ( array('refer', 'file', 'age', 'pass') as $var )
        ${$var} = isset($vars[$var]) ? $vars[$var] : '';

    if ( is_freeze(${'refer'}) || !is_editable(${'refer'}) )
        return array('msg' => $_attach_messages['err_noparm']);

    $obj = new AttachFile(${'refer'}, ${'file'}, ${'age'});
    if ( !$obj->getstatus() )
        return array('msg' => $_attach_messages['err_notfound']);

    return $obj->delete(${'pass'});
}

// 凍結
function attach_freeze( $freeze )
{
    global $vars, $_attach_messages;

    foreach ( array('refer', 'file', 'age', 'pass') as $var )
    {
        ${$var} = isset($vars[$var]) ? $vars[$var] : '';
    }

    if ( is_freeze(${'refer'}) || !is_editable(${'refer'}) )
    {
        return array('msg' => $_attach_messages['err_noparm']);
    }
    else
    {
        $obj = new AttachFile(${'refer'}, ${'file'}, ${'age'});
        return $obj->getstatus() ?
                $obj->freeze($freeze, ${'pass'}) :
                array('msg' => $_attach_messages['err_notfound']);
    }
}

// リネーム
function attach_rename()
{
    global $vars, $_attach_messages;

    foreach ( array('refer', 'file', 'age', 'pass', 'newname') as $var )
    {
        ${$var} = isset($vars[$var]) ? $vars[$var] : '';
    }

    if ( is_freeze(${'refer'}) || !is_editable(${'refer'}) )
    {
        return array('msg' => $_attach_messages['err_noparm']);
    }
    $obj = new AttachFile(${'refer'}, ${'file'}, ${'age'});
    if ( !$obj->getstatus() )
        return array('msg' => $_attach_messages['err_notfound']);

    return $obj->rename(${'pass'}, ${'newname'});
}

// ダウンロード
function attach_open()
{
    global $vars, $_attach_messages;

    foreach ( array('refer', 'file', 'age') as $var )
    {
        ${$var} = isset($vars[$var]) ? $vars[$var] : '';
    }

    $obj = new AttachFile(${'refer'}, ${'file'}, ${'age'});
    return $obj->getstatus() ?
            $obj->open() :
            array('msg' => $_attach_messages['err_notfound']);
}

// 一覧取得
function attach_list()
{
    global $vars, $_attach_messages;

    $refer = isset($vars['refer']) ? $vars['refer'] : '';

    $obj = new AttachPages($refer);

    $msg = $_attach_messages[($refer == '') ? 'msg_listall' : 'msg_listpage'];
    $body = ($refer == '' || isset($obj->pages[$refer])) ?
            $obj->toString($refer, FALSE) :
            $_attach_messages['err_noexist'];

    return array('msg' => $msg, 'body' => $body);
}

// アップロードフォームを表示 (action時)
function attach_showform()
{
    global $vars, $_attach_messages;

    $page = isset($vars['page']) ? $vars['page'] : '';
    $vars['refer'] = $page;
    $body = attach_form($page);

    return array('msg' => $_attach_messages['msg_upload'], 'body' => $body);
}

//-------- サービス
// mime-typeの決定
function attach_mime_content_type( $filename )
{
    $type = 'application/octet-stream'; // default

    if ( !file_exists($filename) )
        return $type;

    $size = @getimagesize($filename);
    if ( is_array($size) )
    {
        switch ( $size[2] )
        {
            case 1: return 'image/gif';
            case 2: return 'image/jpeg';
            case 3: return 'image/png';
            case 4: return 'application/x-shockwave-flash';
        }
    }

    $matches = array();
    if ( !preg_match('/_((?:[0-9A-F]{2})+)(?:\.\d+)?$/', $filename, $matches) )
        return $type;

    $filename = decode($matches[1]);

    // mime-type一覧表を取得
    $config = new Config(PLUGIN_ATTACH_CONFIG_PAGE_MIME);
    $table = $config->read() ? $config->get('mime-type') : array();
    unset($config); // メモリ節約

    foreach ( $table as $row )
    {
        $_type = trim($row[0]);
        $exts = preg_split('/\s+|,/', trim($row[1]), -1, PREG_SPLIT_NO_EMPTY);
        foreach ( $exts as $ext )
        {
            if ( preg_match("/\.$ext$/i", $filename) )
                return $_type;
        }
    }

    return $type;
}

// アップロードフォームの出力
function attach_form( $page )
{
    global $script, $vars, $_attach_messages;

    $r_page = popowiki\core\Link::urlencode_pagename($page);
    $s_page = HtmlUtils::escapeHTML($page);
    $navi = <<<EOD
  <span class="small">
   [<a href="$script?plugin=attach&amp;pcmd=list&amp;refer=$r_page">{$_attach_messages['msg_list']}</a>]
   [<a href="$script?plugin=attach&amp;pcmd=list">{$_attach_messages['msg_listall']}</a>]
  </span><br />
EOD;

    if ( !ini_get('file_uploads') )
        return '#attach(): file_uploads disabled<br />' . $navi;
    if ( !is_page($page) )
        return '#attach(): No such page<br />' . $navi;

    $maxsize = PLUGIN_ATTACH_MAX_FILESIZE;
    $msg_maxsize = sprintf($_attach_messages['msg_maxsize'], number_format($maxsize / 1024) . 'KB');

    $pass = '';
    if ( PLUGIN_ATTACH_PASSWORD_REQUIRE || PLUGIN_ATTACH_UPLOAD_ADMIN_ONLY )
    {
        $title = $_attach_messages[PLUGIN_ATTACH_UPLOAD_ADMIN_ONLY ? 'msg_adminpass' : 'msg_password'];
        $pass = '<br />' . $title . ': <input type="password" name="pass" size="20" />';
    }
    return <<<EOD
<form enctype="multipart/form-data" action="$script" method="post">
 <div>
  <input type="hidden" name="plugin" value="attach" />
  <input type="hidden" name="pcmd"   value="post" />
  <input type="hidden" name="refer"  value="$s_page" />
  <input type="hidden" name="max_file_size" value="$maxsize" />
  $navi
  <span class="small">
   $msg_maxsize
  </span><br />
  <label for="_p_attach_file">{$_attach_messages['msg_file']}:</label> <input type="file" name="attach_file" id="_p_attach_file" />
  $pass
  <input type="submit" value="{$_attach_messages['btn_upload']}" />
 </div>
</form>
EOD;
}

//-------- クラス
// ファイル
class AttachFile {

    var $page, $file, $age, $basename, $filename, $logname;
    var $time = 0;
    var $size = 0;
    var $time_str = '';
    var $size_str = '';
    var $status = array('count' => array(0), 'age' => '', 'pass' => '', 'freeze' => FALSE);

    function __construct( $page, $file, $age = 0 )
    {
        $this->page = $page;
        $this->file = preg_replace('#^.*/#', '', $file);
        $this->age = is_numeric($age) ? $age : 0;

        $this->basename = UPLOAD_DIR . encode($page) . '_' . encode($this->file);
        $this->filename = $this->basename . ($age ? '.' . $age : '');
        $this->logname = $this->basename . '.log';
        $this->exist = file_exists($this->filename);
        $this->time = $this->exist ? filemtime($this->filename) - LOCALZONE : 0;
    }

    function gethash()
    {
        return $this->exist ? md5_file($this->filename) : '';
    }

    // ファイル情報取得
    function getstatus()
    {
        if ( !$this->exist )
            return FALSE;

        // ログファイル取得
        if ( file_exists($this->logname) )
        {
            $data = file($this->logname);
            foreach ( $this->status as $key => $value )
            {
                $this->status[$key] = chop(array_shift($data));
            }
            $this->status['count'] = explode(',', $this->status['count']);
        }
        $this->time_str = get_date('Y/m/d H:i:s', $this->time);
        $this->size = filesize($this->filename);
        $this->size_str = sprintf('%01.1f', round($this->size / 1024, 1)) . 'KB';
        $this->type = attach_mime_content_type($this->filename);

        return TRUE;
    }

    // ステータス保存
    function putstatus()
    {
        $this->status['count'] = join(',', $this->status['count']);
        $fp = fopen($this->logname, 'wb') or
                die_message('cannot write ' . $this->logname);
        set_file_buffer($fp, 0);
        flock($fp, LOCK_EX);
        rewind($fp);
        foreach ( $this->status as $key => $value )
        {
            fwrite($fp, $value . "\n");
        }
        flock($fp, LOCK_UN);
        fclose($fp);
    }

    // 日付の比較関数
    public static function datecomp( $a, $b )
    {
        return ($a->time == $b->time) ? 0 : (($a->time > $b->time) ? -1 : 1);
    }

    function toString( $showicon, $showinfo )
    {
        global $script, $_attach_messages;

        $this->getstatus();
        $param = '&amp;file=' . rawurlencode($this->file) . '&amp;refer=' . popowiki\core\Link::urlencode_pagename($this->page) .
                ($this->age ? '&amp;age=' . $this->age : '');
        $title = $this->time_str . ' ' . $this->size_str;
        $label = ($showicon ? PLUGIN_ATTACH_FILE_ICON : '') . HtmlUtils::escapeHTML($this->file);
        if ( $this->age )
        {
            $label .= ' (backup No.' . $this->age . ')';
        }
        $info = $count = '';
        if ( $showinfo )
        {
            $_title = str_replace('$1', rawurlencode($this->file), $_attach_messages['msg_info']);
            $info = "\n<span class=\"small\">[<a href=\"$script?plugin=attach&amp;pcmd=info$param\" title=\"$_title\">{$_attach_messages['btn_info']}</a>]</span>\n";
            $count = ($showicon && !empty($this->status['count'][$this->age])) ?
                    sprintf($_attach_messages['msg_count'], $this->status['count'][$this->age]) : '';
        }
        return "<a href=\"$script?plugin=attach&amp;pcmd=open$param\" title=\"$title\">$label</a>$count$info";
    }

    // 情報表示
    function info( $err )
    {
        global $script, $_attach_messages, $user;

        $r_page = popowiki\core\Link::urlencode_pagename($this->page);
        $s_page = HtmlUtils::escapeHTML($this->page);
        $s_file = HtmlUtils::escapeHTML($this->file);
        $s_err = ($err == '') ? '' : '<p style="font-weight:bold">' . $_attach_messages[$err] . '</p>';

        $msg_rename = '';
        if ( $this->age )
        {
            $msg_freezed = '';
            $msg_delete = '<input type="radio" name="pcmd" id="_p_attach_delete" value="delete" />' .
                    '<label for="_p_attach_delete">' . $_attach_messages['msg_delete'] .
                    $_attach_messages['msg_require'] . '</label><br />';
            $msg_freeze = '';
        }
        else
        {
            if ( $this->status['freeze'] )
            {
                $msg_freezed = "<dd>{$_attach_messages['msg_isfreeze']}</dd>";
                $msg_delete = '';
                $msg_freeze = '<input type="radio" name="pcmd" id="_p_attach_unfreeze" value="unfreeze" />' .
                        '<label for="_p_attach_unfreeze">' . $_attach_messages['msg_unfreeze'] .
                        $_attach_messages['msg_require'] . '</label><br />';
            }
            else
            {
                $msg_freezed = '';
                $msg_delete = '<input type="radio" name="pcmd" id="_p_attach_delete" value="delete" />' .
                        '<label for="_p_attach_delete">' . $_attach_messages['msg_delete'];
                if ( PLUGIN_ATTACH_DELETE_ADMIN_ONLY || $this->age )
                    $msg_delete .= $_attach_messages['msg_require'];
                $msg_delete .= '</label><br />';
                $msg_freeze = '<input type="radio" name="pcmd" id="_p_attach_freeze" value="freeze" />' .
                        '<label for="_p_attach_freeze">' . $_attach_messages['msg_freeze'] .
                        $_attach_messages['msg_require'] . '</label><br />';

                if ( PLUGIN_ATTACH_RENAME_ENABLE )
                {
                    $msg_rename = '<input type="radio" name="pcmd" id="_p_attach_rename" value="rename" />' .
                            '<label for="_p_attach_rename">' . $_attach_messages['msg_rename'] .
                            $_attach_messages['msg_require'] . '</label><br />&nbsp;&nbsp;&nbsp;&nbsp;' .
                            '<label for="_p_attach_newname">' . $_attach_messages['msg_newname'] .
                            ':</label> ' .
                            '<input type="text" name="newname" id="_p_attach_newname" size="40" value="' .
                            $this->file . '" /><br />';
                }
            }
        }
        $info = $this->toString(TRUE, FALSE);
        $hash = $this->gethash();

        $msg_filename = '';
        $msg_date = '';
        $msg_dlcount = '';
        $ContentType = '';
        $navigation = "";
        if ($user && $user->isLoggedIn())
         {
             $msg_filename = " <dd>{$_attach_messages['msg_filename']}:{$this->filename}</dd>";
             $msg_date = " <dd>{$_attach_messages['msg_date']}:{$this->time_str}</dd>";
             $msg_dlcount = " <dd>{$_attach_messages['msg_dlcount']}:{$this->status['count'][$this->age]}</dd>";
             $ContentType = " <dd>Content-type:{$this->type}</dd>";
             $navigation = <<<EOD
<p class="small">
 [<a href="$script?plugin=attach&amp;pcmd=list&amp;refer=$r_page">{$_attach_messages['msg_list']}</a>]
 [<a href="$script?plugin=attach&amp;pcmd=list">{$_attach_messages['msg_listall']}</a>]
</p>
EOD;
         }

        $retval = array('msg' => sprintf($_attach_messages['msg_info'], HtmlUtils::escapeHTML($this->file)));
        $retval['body'] = <<< EOD
${navigation}
<dl>
 <dt>$info</dt>
 <dd>{$_attach_messages['msg_page']}:$s_page</dd>
${msg_filename}
 <dd>{$_attach_messages['msg_md5hash']}:$hash</dd>
 <dd>{$_attach_messages['msg_filesize']}:{$this->size_str} ({$this->size} bytes)</dd>
${ContentType}
${msg_date}
${msg_dlcount}
 $msg_freezed
</dl>
<hr />
$s_err
<form action="$script" method="post">
 <div>
  <input type="hidden" name="plugin" value="attach" />
  <input type="hidden" name="refer" value="$s_page" />
  <input type="hidden" name="file" value="$s_file" />
  <input type="hidden" name="age" value="{$this->age}" />
  $msg_delete
  $msg_freeze
  $msg_rename
  <br />
  <label for="_p_attach_password">{$_attach_messages['msg_password']}:</label>
  <input type="password" name="pass" id="_p_attach_password" size="20" />
  <input type="submit" value="{$_attach_messages['btn_submit']}" />
 </div>
</form>
EOD;
        return $retval;
    }

    function delete( $pass )
    {
        global $_attach_messages, $notify, $notify_subject;

        if ( $this->status['freeze'] )
            return attach_info('msg_isfreeze');

        if ( !pkwk_login($pass) )
        {
            if ( PLUGIN_ATTACH_DELETE_ADMIN_ONLY || $this->age )
            {
                return attach_info('err_adminpass');
            }
            else if ( PLUGIN_ATTACH_PASSWORD_REQUIRE &&
                    md5($pass) !== $this->status['pass'] )
            {
                return attach_info('err_password');
            }
        }

        // バックアップ
        if ( $this->age ||
                (PLUGIN_ATTACH_DELETE_ADMIN_ONLY && PLUGIN_ATTACH_DELETE_ADMIN_NOBACKUP) )
        {
            @unlink($this->filename);
        }
        else
        {
            do
            {
                $age = ++$this->status['age'];
            }
            while ( file_exists($this->basename . '.' . $age) );

            if ( !rename($this->basename, $this->basename . '.' . $age) )
            {
                // 削除失敗 why?
                return array('msg' => $_attach_messages['err_delete']);
            }

            $this->status['count'][$age] = $this->status['count'][0];
            $this->status['count'][0] = 0;
            $this->putstatus();
        }

        if ( is_page($this->page) )
            touch(get_filename($this->page));

        if ( $notify )
        {
            $footer['ACTION'] = 'File deleted';
            $footer['FILENAME'] = & $this->file;
            $footer['PAGE'] = & $this->page;
            $footer['URI'] = get_script_uri() .
                    '?' . popowiki\core\Link::urlencode_pagename($this->page);
            $footer['USER_AGENT'] = TRUE;
            $footer['REMOTE_ADDR'] = TRUE;
            pkwk_mail_notify($notify_subject, "\n", $footer) or
                    die('pkwk_mail_notify(): Failed');
        }

        return array('msg' => $_attach_messages['msg_deleted']);
    }

    function rename( $pass, $newname )
    {
        global $_attach_messages, $notify, $notify_subject;

        if ( $this->status['freeze'] )
            return attach_info('msg_isfreeze');

        if ( !pkwk_login($pass) )
        {
            if ( PLUGIN_ATTACH_DELETE_ADMIN_ONLY || $this->age )
            {
                return attach_info('err_adminpass');
            }
            else if ( PLUGIN_ATTACH_PASSWORD_REQUIRE &&
                    md5($pass) !== $this->status['pass'] )
            {
                return attach_info('err_password');
            }
        }
        $newbase = UPLOAD_DIR . encode($this->page) . '_' . encode($newname);
        if ( file_exists($newbase) )
        {
            return array('msg' => $_attach_messages['err_exists']);
        }
        if ( !PLUGIN_ATTACH_RENAME_ENABLE || !rename($this->basename, $newbase) )
        {
            return array('msg' => $_attach_messages['err_rename']);
        }

        return array('msg' => $_attach_messages['msg_renamed']);
    }

    function freeze( $freeze, $pass )
    {
        global $_attach_messages;

        if ( !pkwk_login($pass) )
            return attach_info('err_adminpass');

        $this->getstatus();
        $this->status['freeze'] = $freeze;
        $this->putstatus();

        return array('msg' => $_attach_messages[$freeze ? 'msg_freezed' : 'msg_unfreezed']);
    }

    function open()
    {
        $this->getstatus();
        $this->status['count'][$this->age] ++;
        $this->putstatus();
        $filename = $this->file;

        // Care for Japanese-character-included file name
        if ( LANG == 'ja' )
        {
            switch ( UA_NAME . '/' . UA_PROFILE )
            {
                case 'Opera/default':
                    // Care for using _auto-encode-detecting_ function
                    $filename = mb_convert_encoding($filename, 'UTF-8', 'auto');
                    break;
                case 'MSIE/default':
                    $filename = mb_convert_encoding($filename, 'SJIS-win', 'auto');
                    break;
            }
        }
        $utf8filename = mb_convert_encoding($filename, 'UTF-8', 'auto');

        // workaround unsupport RFC 6266
        //   http://support.microsoft.com/kb/436616/ja
        //   "Content-Disposition", "Attachment; filename*=utf-8''" + Server.UrlEncode(FileName));
        $ContentDisposition = 'Content-Disposition: inline' .
//              '; filename="' . HtmlUtils::escapeHTML($filename) . '"' .
                "; filename*=utf-8''" . rawurlencode($utf8filename) ;

        ini_set('default_charset', '');
        mb_http_output('pass');

        pkwk_common_headers();
        header( $ContentDisposition );
        header( 'Content-Length: ' . $this->size );
        header( 'Content-Type: '   . $this->type );

        @readfile($this->filename);
        exit;
    }
    
    static public function checkAndRemoveExif($filename, &$ErrMsg)
    {
        $ErrMsg = '';
        // Todo: file is image or not
        // Todo: tiff format
        // remove exif info for privacy protection
        if ($fp = @fopen($filename, "r"))
        {
            $header = fread($fp, 4);
            fclose($fp);
            // Todo: tiff format
            if ($header == "\xFF\xD8\xFF\xE1" || $header == "\xFF\xD8\xFF\xE0" )
            { // jpeg
                // jhead cmd : jhead -purejpg $filename
                $success = FALSE;
                $has_exif = 'unknown';
                $has_gps  = 'unknown';
                if ( extension_loaded('exif') )
                {
                    $exif = @exif_read_data( $filename , 'IFD0' );
                    if ( $exif === FALSE )
                    {
                        $data = file_get_contents($filename);
                        $has_gps = (strpos('WGS', $data) !== FALSE);
                        // exif_read_data can not detect GPS Tag : FUJIFILM
                        if ( !$has_gps && strpos('FUJIFILM', $data) === FALSE )
                            return TRUE;
                        unset($data);
                     }
                     $has_exif = ($exif !== FALSE);
                     $exif = @exif_read_data( $filename , 0 , TRUE );
                     if ( isset( $exif['GPS'] ) )
                         $has_gps = TRUE;
                }
                if ( extension_loaded('imagick') )
                {
                    $im = new Imagick( $filename );
                    if ($im)
                    {
//                        $im->setFormat( "jpg" );
//                        $im->readImage( $filename );
                        if ( $im->stripImage() )
                        {
                           if( @$im->writeImage( $filename ) )
                              $success = TRUE;
                        }
                        $im->destroy();
                    }
                }
                if (!$success && extension_loaded('gd'))
                {
                    $im = @imagecreatefromjpeg($filename);
                    if ($im !== FALSE)
                    {
                        if (@imagejpeg($im, $filename)) // quality default 75
                              $success = TRUE;
                        imagedestroy($im);
                    }
                }
                //  todo: error
                if (!$success)
                {
                    if ($has_exif === TRUE)
                        $ErrMsg .= 'your image contains exif info.';
                    if ($has_gps === TRUE)
                        $ErrMsg .= 'your image contains exif gps info.';
                }
                return $success;
            }
        }
        else
        {
            $ErrMsg .= 'can not open file.';
            return FALSE;
        }
        return TRUE;
    }
    
}

// ファイルコンテナ
class AttachFiles {

    var $page;
    var $files = array();

    function __construct( $page )
    {
        $this->page = $page;
    }

    function add( $file, $age )
    {
        $this->files[$file][$age] = new AttachFile($this->page, $file, $age);
    }

    // ファイル一覧を取得
    function toString( $flat )
    {
        global $_title_cannotread;

        if ( !check_readable($this->page, FALSE, FALSE) )
        {
            return str_replace('$1', make_pagelink($this->page), $_title_cannotread);
        }
        else if ( $flat )
        {
            return $this->to_flat();
        }

        $ret = '';
        $files = array_keys($this->files);
        sort($files, SORT_STRING);

        foreach ( $files as $file )
        {
            $_files = array();
            foreach ( array_keys($this->files[$file]) as $age )
            {
                $_files[$age] = $this->files[$file][$age]->toString(FALSE, TRUE);
            }
            if ( !isset($_files[0]) )
            {
                $_files[0] = HtmlUtils::escapeHTML($file);
            }
            ksort($_files, SORT_NUMERIC);
            $_file = $_files[0];
            unset($_files[0]);
            $ret .= " <li>$_file\n";
            if ( count($_files) )
            {
                $ret .= "<ul>\n<li>" . join("</li>\n<li>", $_files) . "</li>\n</ul>\n";
            }
            $ret .= " </li>\n";
        }
        return make_pagelink($this->page) . "\n<ul>\n$ret</ul>\n";
    }

    // ファイル一覧を取得(inline)
    function to_flat()
    {
        $ret = '';
        $files = array();
        foreach ( array_keys($this->files) as $file )
        {
            if ( isset($this->files[$file][0]) )
            {
                $files[$file] = & $this->files[$file][0];
            }
        }
        uasort($files, array('AttachFile', 'datecomp'));
        foreach ( array_keys($files) as $file )
        {
            $ret .= $files[$file]->toString(TRUE, TRUE) . ' ';
        }

        return $ret;
    }

}

// ページコンテナ
class AttachPages {

    var $pages = array();

    function __construct( $page = '', $age = NULL )
    {
        global $user;

        $dir = opendir(UPLOAD_DIR) or
                die('directory ' . UPLOAD_DIR . ' is not exist or not readable.');

        $page_pattern = ($page == '') ? '(?:[0-9A-F]{2})+' : preg_quote(encode($page), '/');
        $age_pattern = ($age === NULL) ?
                '(?:\.([0-9]+))?' : ($age ? "\.($age)" : '');
        $pattern = "/^({$page_pattern})_((?:[0-9A-F]{2})+){$age_pattern}$/";

        $matches = array();
        while ( ($file = readdir($dir)) !== FALSE )
        {
            if ( !preg_match($pattern, $file, $matches) )
                continue;

            if (!$user || !$user->isLoggedIn())
            {
//                continue;
                $pat = '#\.(jpe?g|gif|png|ico|bmp|tiff)$#i';
                if ( preg_match($pattern, $file) )
                    continue;
            }

            $_page = decode($matches[1]);
            $_file = decode($matches[2]);
            $_age = isset($matches[3]) ? $matches[3] : 0;
            if ( !isset($this->pages[$_page]) )
            {
                $this->pages[$_page] = new AttachFiles($_page);
            }
            $this->pages[$_page]->add($_file, $_age);
        }
        closedir($dir);
    }

    function toString( $page = '', $flat = FALSE )
    {
        if ( $page != '' )
        {
            if ( !isset($this->pages[$page]) )
            {
                return '';
            }
            else
            {
                return $this->pages[$page]->toString($flat);
            }
        }
        $ret = '';

        $pages = array_keys($this->pages);
        sort($pages, SORT_STRING);

        foreach ( $pages as $page )
        {
            if ( check_non_list($page) )
                continue;
            $ret .= '<li>' . $this->pages[$page]->toString($flat) . '</li>' . "\n";
        }
        return "\n" . '<ul>' . "\n" . $ret . '</ul>' . "\n";
    }

}

function plugin_attach_allow_no_login()
{
    return TRUE;
}
