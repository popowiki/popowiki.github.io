<?php

// $Id: bugtrack_list.inc.php,v 1.6 2005/04/03 02:51:07 henoheno Exp $
//
// PukiWiki BugTrack-list plugin - A part of BugTrack plugin
//
// Copyright
// 2002-2005 PukiWiki Developers Team
// 2002 Y.MASUI GPL2 http://masui.net/pukiwiki/ masui@masui.net
/**/

require_once(PLUGIN_DIR . 'bugtrack.inc.php');

function plugin_bugtrack_list_init()
{
    plugin_bugtrack_init();
}

function plugin_bugtrack_list_allow_no_login()
{
    return TRUE;
}

