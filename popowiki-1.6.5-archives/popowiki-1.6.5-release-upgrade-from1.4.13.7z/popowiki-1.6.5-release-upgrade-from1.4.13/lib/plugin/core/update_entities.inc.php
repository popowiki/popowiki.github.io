<?php

// PukiWiki - Yet another WikiWikiWeb clone
// $Id: update_entities.inc.php,v 1.15 2007/04/08 10:29:24 henoheno Exp $
// Copyright (C) 2003-2007 PukiWiki Developers Team
// License: GPL v2 or (at your option) any later version
//
// Update entities plugin - Update XHTML entities from DTD (for admin)
/**/

define('W3C_XHTML_DTD_LOCATION', 'http://www.w3.org/TR/xhtml1/DTD/');

// html : http://www.w3.org/TR/xhtml1/dtds.html
// zip file : http://www.w3.org/TR/xhtml1/xhtml1.zip

function plugin_update_entities_init()
{
    $messages = array(
        '_entities_messages' => array(
            'title_update' => 'キャッシュ更新',
            'title_update-comfirm' => 'キャッシュ更新確認',
            'msg_adminpass' => '管理者パスワード',
            'btn_submit' => '実行',
            'msg_done' => 'キャッシュの更新が完了しました。',
            'msg_usage' => '
* 処理内容

:文字実体参照にマッチする正規表現パターンのキャッシュを更新|
PHPの持つテーブルおよびW3CのDTDをスキャンして、キャッシュに記録します。

* 処理対象
「COLOR(red){not found.}」と表示されたファイルは処理されません。
-%s

* 実行
管理者パスワードを入力して、[実行]ボタンをクリックしてください。
',
            'password_error' => 'パスワードが違います'
    ));
    set_plugin_messages($messages);
}

function plugin_update_entities_action()
{
    global $script, $vars;
    global $_entities_messages;

    if ( PKWK_READONLY )
        die_message('PKWK_READONLY prohibits this');

    // avoid DOS Attack
    // 1. check admin pass
    // 2. check items by admin & check pass
    // 3. update items
    // or file cache

    $msg = $body = '';

    if ( empty($vars['action']) || empty($vars['adminpass']) || !pkwk_login($vars['adminpass']) )
    {
        $msg = & $_entities_messages['title_update'];
        $body = <<<EOD
<form method="post" action="$script">
 <div>
  <input type="hidden" name="plugin" value="update_entities" />
  <input type="hidden" name="action" value="update-confirm" />
  <label for="_p_update_entities_adminpass">{$_entities_messages['msg_adminpass']}</label>
  <input type="password" name="adminpass" id="_p_update_entities_adminpass" size="20" value="" />
  <input type="submit" value="{$_entities_messages['btn_submit']}" />
 </div>
</form>
EOD;
        if ( isset($vars['action']) && preg_match('/^(update|update-confirm)$/', $vars['action']) )
        {
            $body = $_entities_messages['password_error'] . $body;
        }
    }
    else if ( $vars['action'] == 'update-confirm' )
    {
        $items = plugin_update_entities_create();
        $msg = & $_entities_messages['title_update-comfirm'];
        $body = convert_html(sprintf($_entities_messages['msg_usage'], join("\n" . '-', $items)));
        $body .= <<<EOD
<form method="post" action="$script">
 <div>
  <input type="hidden" name="plugin" value="update_entities" />
  <input type="hidden" name="action" value="update" />
  <label for="_p_update_entities_adminpass">{$_entities_messages['msg_adminpass']}</label>
  <input type="password" name="adminpass" id="_p_update_entities_adminpass" size="20" value="" />
  <input type="submit" value="{$_entities_messages['btn_submit']}" />
 </div>
</form>
EOD;
    }
    else if ( $vars['action'] == 'update' )
    {
        plugin_update_entities_create(TRUE);
        $msg = & $_entities_messages['title_update'];
        $body = & $_entities_messages['msg_done'];
    }
    else
    {
        $msg = & $_entities_messages['title_update'];
        $body = & $_entities_messages['err_invalid'];
    }
    return array('msg' => $msg, 'body' => $body);
}

// Remove &amp; => amp
function plugin_update_entities_strtr( $entity )
{
    return strtr($entity, array('&' => '', ';' => ''));
}

function plugin_update_entities_create( $do = FALSE )
{
    $files = array('xhtml-lat1.ent', 'xhtml-special.ent', 'xhtml-symbol.ent');

    $entities = array_map('plugin_update_entities_strtr', array_values(get_html_translation_table(HTML_ENTITIES)));
    $items = array('php:html_translation_table');
    $matches = array();
    foreach ( $files as $file )
    {
        $temp_fname = CACHE_DIR . $file;
        if ( file_exists($temp_fname) )
        {
            $source = file($temp_fname);
        }
        else
        {
//           FIXME: 'allow_url_fopen = Off' will stop this
//            -->  (1) download xhtml1.zip
//            -->  (2) save to cache manually
//                     'xhtml-lat1.ent', 'xhtml-special.ent', 'xhtml-symbol.ent'
            $old_user_agent = ini_get('user_agent');
            try
            {
                ini_set('user_agent', 'Mozilla/5.0 (compatible)');
                $source = file(W3C_XHTML_DTD_LOCATION . $file);
                //			 or die_message('cannot receive ' . W3C_XHTML_DTD_LOCATION . $file . '.');
                if ( ( $source !== false) && (count($source) > 30) )
                {
                    // save to cache
                    echo count($source);
                    $fp = fopen($temp_fname, 'w');
                    if ( $fp )
                    {
                        fwrite($fp, implode($source));
                        fclose($fp);
                    }
                }
            }
            catch ( Exception $ex )
            {
                ini_set('user_agent', $old_user_agent);
            }
            ini_set('user_agent', $old_user_agent);
        }

        if ( !is_array($source) )
        {
            $items[] = 'w3c:' . $file . ' COLOR(red):not found.';
            continue;
        }
        $items[] = 'w3c:' . $file;
        if ( preg_match_all('/<!ENTITY\s+([A-Za-z0-9]+)/', join('', $source), $matches, PREG_PATTERN_ORDER) )
        {
            $entities = array_merge($entities, $matches[1]);
        }
    }
    if ( !$do )
        return $items;

    $entities = array_unique($entities);
    sort($entities, SORT_STRING);
    $min = 999;
    $max = 0;
    foreach ( $entities as $entity )
    {
        $len = strlen($entity);
        $max = max($max, $len);
        $min = min($min, $len);
    }

    $pattern = sprintf('(?=[a-zA-Z0-9]{%d,%d})', $min, $max)
            . generate_trie_regex($entities);
    $fp = fopen(CACHE_DIR . PKWK_ENTITIES_REGEX_CACHE, 'w')
            or die_message('cannot write file PKWK_ENTITIES_REGEX_CACHE<br />' . "\n" .
                    'maybe permission is not writable or filename is too long');
    fwrite($fp, $pattern);
    fclose($fp);

    return $items;
}

function plugin_update_entities_allow_no_login()
{
    return FALSE;
}