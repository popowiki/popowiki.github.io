<?php
/*
 * PopoWiki   PHP Web Wiki System
 * Copyright (C) 2014-2019 PopoWiki Project
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * (see licenses/ for more info)
 */
namespace popowiki\core;
//use ;

class User
{
    public $loggedin = 0;

    private $password;

    public $cookiekey;

    // user info
    public $id = -1;
    public $loginid = '';
    public $realname;
    public $displayname;
    public $email;
    public $url;
    public $language = '';
    public $admin = 0;
    public $canlogin = 0;
    public $notes;
    private $halt = 0;

    public function __construct()
    {
        $this->auth_users = array();
        $this->invalid_passwd = FALSE;
    }

    private function init_user()
    {
        $this->loggedin = 0;
        $this->admin = 0;
        $this->cookiekey = '';
        $this->loginid = '';

        $this->id = -1;

    }

    function login($loginid, $password) {
        $this->loggedin = 0;
        $allowlocal = 1;

        if ( POPOWIKI_READONLY )
            return 0;

        $loginid = @strval($loginid);
        $password = trim(@strval($password));

        if (!$this->readFromLoginId($loginid))
            return 0;

        if (!$this->checkPassword($password))
            return 0;

        if (!isset($_SESSION) && !session_start( array(
            'cookie_lifetime' => 60*60*6,
            ) ) )
        {
            $this->init_user();
            return 0;
        }
        $_SESSION['id']      = -1; // reserved for db
        $_SESSION['ip']      = $_SERVER['REMOTE_ADDR'];
        $_SESSION['loginid'] = $loginid;

        $this->loginid = $loginid;

        $this->loggedin = 1;
        return $this->isLoggedIn();

        return 0;
    }

    private function readFromLoginId($loginid)
    {
        if ($this->isValidLoginName($loginid))
        {
            $this->loginid = $loginid;
            return 1;
        }
        $this->init_user();
        return 0;
    }

//    private function readFromId($id)
//    {
//        $this->init_user();
//        return 0;
//    }

    private function readFromSession()
    {
        if (!$this->readFromLoginId($_SESSION['loginid']))
            return 0;
        return 1;
    }

    function sessionLogin()
	{
        if ( POPOWIKI_READONLY )
            return 0;

        $this->loggedin = 0;
		if (!$this->readFromSession())
			return 0;
		if (!$this->checkSessionKey())
			return 0;
		$this->loggedin = 1;
		return $this->isLoggedIn();
	}

    private function checkSessionKey()
	{
        $session_name = session_name();
        $key = (isset($_COOKIE[$session_name]) ? $_COOKIE[$session_name] : '');
        $success = (($key != ''));
//        $success = (($key != '') && ($key == $this->getSessionKey()));

        if ($_SESSION['ip'] != $_SERVER['REMOTE_ADDR'])
            $success = 0;

        if ($success)
            return $success;
        $this->init_user();
        return 0;
	}

    private function getSessionKey()
    {
        return $this->cookiekey;
    }

	function logout() {
		$this->loggedin = 0;
	}

	function isLoggedIn() {
		return $this->loggedin;
	}

    function checkPassword($password)
    {
        $block_list = array();

        if (($_SERVER['REMOTE_ADDR'] != '127.0.0.1') && ($_SERVER['REMOTE_ADDR'] != '::1'))
        {  //  IPv6 ::1  IPv4 127.0.0.1
            $block_list = array('foo', 'bar','hoge');
            if (in_array(strtolower($password), array('pass','passwd',$this->loginid.'_passwd')))
            {
                $this->init_user();
                $this->invalid_passwd = true;
                return 0;
            }
        }
        $scheme = '';
        if ( preg_match('#^({[^}]+})#', $this->auth_users[$this->loginid], $m))
            $scheme = $m[1];

        if (!in_array(strtolower($this->loginid), $block_list) && !empty($password))
        {
//        foreach(array('pass', 'passwd','_passwd'))
            if (pkwk_hash_compute($password, $scheme) == $this->auth_users[$this->loginid])
                return 1;
        }
        $this->init_user();
        return 0;
    }

    function isValidLoginName($login_name)
    {
        if (!is_string($login_name) || strlen($login_name)==0)
        {
            return FALSE;
        }
        if ( isset($this->auth_users[$login_name]) )
            return TRUE;
        return FALSE;
    }

    function makePassword($plainPasswordText)
   {
////        {x-php-crypt}
//        $item = array();
//        $item[''] = $plainPasswordText;
//        $item[''] = $plainPasswordText;
//        $item['x-php-md5'] = '{x-php-md5}' . md5($plainPasswordText); // PHP md5()
//        $item['SMD5'] = '{SMD5}' . ;
//        x-php-md5($str)
//        SMD5
    }

    public static function AutoLogin()
    {
         global $user, $auth_users;
         $user = new User();

        if (!defined('POPOWIKI_READONLY'))
            define('POPOWIKI_READONLY', (defined('PKWK_READONLY') && PKWK_READONLY));

        $user->auth_users =& $auth_users;

        // Check Auto login
        if (!POPOWIKI_READONLY || isset($_COOKIE[session_name()]))
        {
            if (session_start(array(
                'cookie_lifetime' => 60*60*6,
                )) )
            {
                 if (isset($_SESSION['ip']) && ($_SESSION['ip'] == $_SERVER['REMOTE_ADDR'])
                     && isset($_SESSION['id']))
                 {
                     $user->sessionLogin();
                 }
            }
        }
    }

    static public function checkAllowedHost()
    {
        global $allow_login_host;

        if (!isset($allow_login_host) || !is_array($allow_login_host) || count($allow_login_host)==0)
            return FALSE;

        $remote_ip = (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '?');
        $remote_host = (isset($_SERVER['REMOTE_HOST']) ? $_SERVER['REMOTE_HOST'] : gethostbyaddr($_SERVER['REMOTE_ADDR']));
//        var_dump($allow_login_host, $remote_host);
        if ( !$remote_host )
            return FALSE;
        foreach($allow_login_host as $pattern)
        {
            if ( $pattern && preg_match("#${pattern}\$#i" , $remote_host) )
                return TRUE;
        }
        return FALSE;
    }

}

