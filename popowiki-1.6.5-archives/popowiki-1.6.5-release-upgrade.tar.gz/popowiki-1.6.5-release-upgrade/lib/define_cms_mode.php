<?php


global $deny_plugin_no_login;

// 1:()      , 2:(search), 3:(search,list)
// 11:(login), 12 , 13
// login : +10
if (intval(POPOWIKI_CMS_MODE) <= 10)
{
    popowiki_try_define('PKWK_HIDE_LOGIN_MENU', 1); // ログインへのリンクを非表示にします
}
switch ( intval(POPOWIKI_CMS_MODE) % 10)
{
    case 1:
        $deny_plugin_no_login = array_unique(array_merge($deny_plugin_no_login, array('search','list')));
        break;
    case 2:
//        $deny_plugin_no_login = array_diff($deny_plugin_no_login, array('list'));
        $deny_plugin_no_login = array_unique(array_merge($deny_plugin_no_login, array('list')));
        break;
    case 3:
       break;
    default:
        break;
}

popowiki_try_define('PKWK_HIDE_RSS_MENU', 1);   // RSSを禁止します

popowiki_try_define('PKWK_HIDE_HELP_MENU', 1);  // ヘルプメニューを非表示にします

popowiki_try_define('OUTPUT_HIDE_LASTMODIFIED', 1);
popowiki_try_define('PKWK_SHOW_RELATED', 0);

// HIDE_VERSION_STRING
//popowiki_try_define('HIDE_VERSION_STRING', 1);

// OUTPUT_HIDE_CORE_POWERDBY
//popowiki_try_define('OUTPUT_HIDE_CORE_POWERDBY', 1);

// OUTPUT_HIDE_CONVERT_TIME
popowiki_try_define('OUTPUT_HIDE_CONVERT_TIME', 1);

// OUTPUT_HIDE_SITE_ADMINISTRATOR
//popowiki_try_define('OUTPUT_HIDE_SITE_ADMINISTRATOR', 1);

