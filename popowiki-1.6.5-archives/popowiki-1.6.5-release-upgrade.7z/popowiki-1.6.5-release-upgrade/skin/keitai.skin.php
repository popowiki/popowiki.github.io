<?php
// PukiWiki - Yet another WikiWikiWeb clone.
// $Id: keitai.skin.php,v 1.16 2006/01/09 10:37:05 henoheno Exp $
// Copyright (C) 2003-2006 PukiWiki Developers Team
// License: GPL v2 or (at your option) any later version
//
// Skin for Embedded devices

// 注意 : このスキンは、メンテナンスされていません。

// 警告 : このスキンは将来のバージョンで削除予定です
//   このスキンを対象とした携帯電話は、販売とサポートが終了されています。

// Known issues
// ２ページ以上あるときの問題点
//   タグの定義途中で分断されることがある
//   タグ要素の途中で分断されることがある

// ----
// Prohibit direct access
if (! defined('UI_LANG')) die('UI_LANG is not set');

$pageno = (isset($vars['p']) && is_numeric($vars['p'])) ? $vars['p'] : 0;
$edit = (isset($vars['cmd'])    && $vars['cmd']    == 'edit') ||
	(isset($vars['plugin']) && $vars['plugin'] == 'edit');

global $max_size, $accesskey, $menubar, $_symbol_anchor;
if (!isset($max_size)) $max_size = 6;
$max_size = --$max_size * 1024; // Make 1KByte spare (for $navi, etc)
$link = $_LINK;
$rw = ! PKWK_READONLY;

// ----
// Modify

// Ignore &dagger;s
$body = preg_replace('#<a[^>]+>' . preg_quote($_symbol_anchor, '#') . '</a>#', '', $body);

// Shrink IMG tags (= images) with character strings
// With ALT option
$body = preg_replace('#(<div[^>]+>)?(<a[^>]+>)?<img[^>]*alt="([^"]+)"[^>]*>(?(2)</a>)(?(1)</div>)#i', '[$3]', $body);
// Without ALT option
$body = preg_replace('#(<div[^>]+>)?(<a[^>]+>)?<img[^>]+>(?(2)</a>)(?(1)</div>)#i', '[img]', $body);

// ----

// Check content volume, Page numbers, divided by this skin
$pagecount = ceil(strlen($body) / $max_size);

// Too large contents to edit
if ($edit && $pagecount > 1)
   	die('Unable to edit: Too large contents for your device');

// Get one page
// BUG: broken of the tag
$body = substr($body, $pageno * $max_size, $max_size);

// ----
// Top navigation (text) bar

$navi = array();
$navi[] = '<a href="' . $link['top']  . '" ' . $accesskey . '="0">0.Top</a>';
if ($rw) {
	$navi[] = '<a href="' . $link['new']  . '" ' . $accesskey . '="1">1.New</a>';
	$navi[] = '<a href="' . $link['edit'] . '" ' . $accesskey . '="2">2.Edit</a>';
	if ($is_read && $function_freeze) {
		if (! $is_freeze) {
			$navi[] = '<a href="' . $link['freeze']   . '" ' . $accesskey . '="3">3.Freeze</a>';
		} else {
			$navi[] = '<a href="' . $link['unfreeze'] . '" ' . $accesskey . '="3">3.Unfreeze</a>';
		}
	}
}
$navi[] = '<a href="' . $script . '?' . rawurlencode($menubar) . '" ' . $accesskey . '="4">4.Menu</a>';
$navi[] = '<a href="' . $link['recent'] . '" ' . $accesskey . '="5">5.Recent</a>';

//echo printf("pagecount(%d) %d / %d ", $pagecount , strlen($body) , $max_size);
// Previous / Next block
if ($pagecount > 1) {
	$prev = $pageno - 1;
	$next = $pageno + 1;
	if ($pageno > 0) {
		$navi[] = '<a href="' . $script . '?cmd=read&amp;page=' . $r_page .
			'&amp;p=' . $prev . '" ' . $accesskey . '="7">7.Prev</a>';
	}
	$navi[] = $next . '/' . $pagecount . ' ';
	if ($pageno < $pagecount - 1) {
		$navi[] = '<a href="' . $script . '?cmd=read&amp;page=' . $r_page .
			'&amp;p=' . $next . '" ' . $accesskey . '="8">8.Next</a>';
	}
}

$navi = join(' | ', $navi);

// make out put contents
$contents = "<html><head><title>${title}</title></head><body>${navi}<hr>${body}</body></html>";

function keitai_tidy_convert(&$html, $output_encoding = 'UTF-8')
{
    $tidy = new tidy;
        $config = array(
          'indent' => FALSE,
          'doctype' => 'omit',
          'newline' => 'LF',
          'output-bom' => FALSE,
          'output-xhtml' => FALSE,
          'output-html'  => TRUE,
          'quote-ampersand' => FALSE,
          'fix-backslash'   => FALSE,
          'wrap' => 0
            );

    if (SOURCE_ENCODING != 'UTF-8')
        $tidy->parseString(mb_convert_encoding($html, 'UTF-8', SOURCE_ENCODING), $config , 'UTF8');
    else
        $tidy->parseString($html, $config , 'UTF8');

    $tidy->CleanRepair();

//    $error_count = tidy_error_count($tidy);
    if (TRUE)
    {
        if ($output_encoding != 'UTF-8')
            $html = mb_convert_encoding(tidy_get_output($tidy), $output_encoding, 'UTF-8');
        else
            $html = tidy_get_output($tidy);
    }
    else if ($output_encoding != SOURCE_ENCODING)
            $html = mb_convert_encoding($html, $output_encoding, SOURCE_ENCODING);
//printf("<div>LINE:%d : tidy_error_count(%d) warning_count(%d) : \n<pre>%s</pre></div>\n", __LINE__, tidy_error_count($tidy), tidy_warning_count ($tidy), htmlspecialchars($tidy->errorBuffer));
}
//$tidy_enable = extension_loaded('tidy');
$tidy_enable = FALSE;

// ----
// Output HTTP headers
pkwk_headers_sent();
if(TRUE) {
	// Force Shift JIS encode for Japanese embedded browsers and devices
	header('Content-Type: text/html; charset=Shift_JIS');
    // html fix by tidy
    if ($tidy_enable)
        keitai_tidy_convert($contents, 'SJIS-win');
    else
        $contents = mb_convert_encoding($contents, 'SJIS-win', SOURCE_ENCODING);
} else {
	header('Content-Type: text/html; charset=' . CONTENT_CHARSET);
    if ($tidy_enable)
        keitai_tidy_convert($contents, CONTENT_CHARSET);
}

// Todo: reduce packet

// Output
echo $contents;
